package net.cakemine.playerservers.bungee.events;

import net.md_5.bungee.api.plugin.*;
import net.cakemine.playerservers.bungee.*;
import java.util.*;
import java.io.*;

public class ServerCreateFinishEvent extends Event
{
    PlayerServers pl;
    private final UUID uuid;
    private final String serverName;
    private final int port;
    private final int memx;
    private final int mems;
    private final String template;
    
    public ServerCreateFinishEvent(final PlayerServers pl, final UUID uuid, final String serverName, final int port, final int memx, final int mems, final String template) {
        this.pl = pl;
        this.uuid = uuid;
        this.serverName = serverName;
        this.port = port;
        this.memx = memx;
        this.mems = mems;
        this.template = template;
    }
    
    public UUID getOwnerId() {
        return this.uuid;
    }
    
    public String getOwnerName() {
        return this.pl.utils.getName(this.uuid.toString());
    }
    
    public String getServerName() {
        return this.serverName;
    }
    
    public void setServerName(final String s) {
        this.pl.serverManager.setServerInfo(this.uuid.toString(), "server-name", s);
    }
    
    public int getPort() {
        return this.port;
    }
    
    public int getXmx() {
        return this.memx;
    }
    
    public void setXmx(final int n) {
        this.pl.serverManager.setServerInfo(this.uuid.toString(), "memory", n + "M/" + this.pl.serverManager.serverMap.get(this.uuid.toString()).get("memory").split("\\/")[1]);
    }
    
    public int getXms() {
        return this.mems;
    }
    
    public void setXms(final int n) {
        this.pl.serverManager.setServerInfo(this.uuid.toString(), "memory", this.pl.serverManager.serverMap.get(this.uuid.toString()).get("memory").split("\\/")[0] + "/" + n + "M");
    }
    
    public String getTemplate() {
        return this.template;
    }
    
    public File getServerFolder() {
        return new File(this.pl.serversFolder + File.separator + this.uuid);
    }
}
