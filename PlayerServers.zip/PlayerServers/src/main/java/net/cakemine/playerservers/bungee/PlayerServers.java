package net.cakemine.playerservers.bungee;

import net.md_5.bungee.api.*;
import net.cakemine.playerservers.bungee.commands.*;
import net.md_5.bungee.api.connection.*;
import net.cakemine.playerservers.bungee.wrapper.*;
import net.md_5.bungee.config.*;
import net.cakemine.playerservers.bungee.sync.*;
import java.util.concurrent.*;
import net.md_5.bungee.api.plugin.*;
import java.util.logging.*;
import net.md_5.bungee.api.config.*;
import java.util.*;
import com.google.common.io.*;
import java.net.*;
import java.io.*;

public class PlayerServers extends Plugin
{
    public ProxyServer proxy;
    public ServerManager serverManager;
    public ExpiryTracker expiryTracker;
    public SettingsManager settingsManager;
    public TemplateManager templateManager;
    public PlayerServerAdmin playerServerAdmin;
    public PluginSender sender;
    public PlayerServer playerServer;
    protected static PlayerServersAPI api;
    public Utils utils;
    protected ConfigurationProvider cfg;
    protected Configuration config;
    protected Configuration serverStore;
    protected Configuration messages;
    protected Configuration guis;
    protected Configuration playerStore;
    protected Configuration online;
    public HashMap<String, HashMap<String, String>> permMap;
    public List<String> blockedCmds;
    public List<String> alwaysOP;
    public HashMap<String, String> msgMap;
    public TreeMap<String, String> playerMap;
    public String prefix;
    public String fallbackSrv;
    public String serversFolder;
    public String wrapperAddress;
    public String proxyAddress;
    public boolean debug;
    public boolean useExpiry;
    public boolean resetExpiry;
    public boolean useTitles;
    public boolean autoPurge;
    public boolean usingWindows;
    public boolean permMapChanged;
    public boolean useQueue;
    public boolean onlineMode;
    public boolean playerMapChanged;
    public long autoPurgeTime;
    public long autoPurgeInterval;
    public int downloadsPort;
    public int wrapperPort;
    public int joinDelay;
    public int onlineJoinDelay;
    public int globalMaxServers;
    public int globalMaxRam;
    public HashMap<String, String> defaultMem;
    public String psCommand;
    public String vers;
    public String wrapper;
    public HashMap<ProxiedPlayer, Server> usingHelper;
    protected Controller ctrl;
    
    public PlayerServers() {
        this.proxy = ProxyServer.getInstance();
        this.serverManager = new ServerManager(this);
        this.expiryTracker = new ExpiryTracker(this);
        this.settingsManager = new SettingsManager(this);
        this.templateManager = new TemplateManager(this);
        this.playerServerAdmin = new PlayerServerAdmin(this);
        this.sender = new PluginSender(this);
        this.playerServer = null;
        this.utils = new Utils(this);
        this.cfg = ConfigurationProvider.getProvider((Class)YamlConfiguration.class);
        this.permMap = new HashMap<String, HashMap<String, String>>();
        this.msgMap = new HashMap<String, String>();
        this.playerMap = new TreeMap<String, String>(String.CASE_INSENSITIVE_ORDER);
        this.debug = true;
        this.useExpiry = true;
        this.resetExpiry = false;
        this.useTitles = true;
        this.autoPurge = false;
        this.usingWindows = false;
        this.permMapChanged = false;
        this.useQueue = true;
        this.onlineMode = true;
        this.playerMapChanged = false;
        this.autoPurgeInterval = 21600000L;
        this.joinDelay = 10;
        this.onlineJoinDelay = 3;
        this.globalMaxServers = -1;
        this.globalMaxRam = -1;
        this.defaultMem = new HashMap<String, String>();
        this.psCommand = "playerserver";
        this.vers = "-1";
        this.wrapper = "default";
        this.usingHelper = new HashMap<ProxiedPlayer, Server>();
        this.ctrl = null;
    }
    
    public void onEnable() {
        loadConfig0();
        this.vers = this.getDescription().getVersion();
        this.usingWindows = this.usingWindows();
        this.proxyAddress = this.utils.getProxyIp();
        this.proxy.registerChannel("PlayerServers");
        this.proxy.getPluginManager().registerListener((Plugin)this, (Listener)new Listeners(this));
        this.proxy.getPluginManager().registerListener((Plugin)this, (Listener)new PluginListener(this));
        PlayerServers.api = new PlayerServersAPI(this);
        this.reload();
        this.setupScripts();
        this.playerServer = new PlayerServer(this, this.psCommand);
        this.proxy.getScheduler().schedule((Plugin)this, (Runnable)new RepeatTasks(this), 30L, 30L, TimeUnit.SECONDS);
        this.proxy.getPluginManager().registerCommand((Plugin)this, (Command)new PlayerServer(this, this.psCommand));
        this.proxy.getPluginManager().registerCommand((Plugin)this, (Command)new PlayerServerAdmin(this));
        this.loadOnlineServers();
    }
    
    public void onDisable() {
        this.proxy.getScheduler().cancel((Plugin)this);
        if (this.wrapper.equalsIgnoreCase("default")) {
            this.ctrl.disconnect();
        }
    }
    
    public boolean usingWindows() {
        return System.getProperty("os.name").matches("(?i)(.*)(windows)(.*)");
    }
    
    public void reload() {
        final String psCommand = this.psCommand;
        this.playerMap.clear();
        this.msgMap.clear();
        this.serverManager.serverMap.clear();
        this.templateManager.templates.clear();
        this.loadFiles();
        this.updateConfig();
        this.loadConfig();
        this.vers = "41075";
        this.loadMsgs();
        this.loadGUIs();
        this.loadServers();
        this.loadPlayers();
        this.loadPermissions();
        this.templateManager.loadTemplates();
        this.utils.vCheck();
        this.sender.reSyncAll();
        if (!this.psCommand.equalsIgnoreCase(psCommand)) {
            this.proxy.getPluginManager().unregisterCommands((Plugin)this);
            this.proxy.getPluginManager().registerCommand((Plugin)this, (Command)new PlayerServer(this, this.psCommand));
            this.proxy.getPluginManager().registerCommand((Plugin)this, (Command)new PlayerServerAdmin(this));
        }
        if (this.ctrl == null && this.wrapper.equalsIgnoreCase("default")) {
            this.proxy.getScheduler().runAsync((Plugin)this, (Runnable)(this.ctrl = new Controller(this)));
        }
        else if (this.ctrl == null && this.wrapper.equalsIgnoreCase("remote")) {
            (this.ctrl = new Controller(this)).setAddress(this.wrapperAddress);
            this.proxy.getScheduler().runAsync((Plugin)this, (Runnable)this.ctrl);
        }
        this.onlineMode = this.proxy.getConfig().isOnlineMode();
    }
    
    public void loadFiles() {
        if (!this.getDataFolder().exists()) {
            this.getDataFolder().mkdir();
        }
        final File file = new File(this.getDataFolder(), "config.yml");
        this.copyResource(file);
        try {
            this.config = this.cfg.load(file);
        }
        catch (IOException ex) {
            this.utils.log(Level.SEVERE, "Failed to load config.yml file! Please send this stack trace to the developer.");
            ex.printStackTrace();
        }
        final File file2 = new File(this.getDataFolder(), "servers.yml");
        this.copyResource(file2);
        try {
            this.serverStore = this.cfg.load(file2);
        }
        catch (IOException ex2) {
            this.utils.log(Level.SEVERE, "Failed to load servers.yml file! Please send this stack trace to the developer.");
            ex2.printStackTrace();
        }
        final File file3 = new File(this.getDataFolder(), "messages.yml");
        this.copyResource(file3);
        try {
            this.messages = this.cfg.load(file3);
        }
        catch (IOException ex3) {
            this.utils.log(Level.SEVERE, "Failed to load messages.yml file! Please send this stack trace to the developer.");
            ex3.printStackTrace();
        }
        final File file4 = new File(this.getDataFolder(), "guis.yml");
        this.copyResource(file4);
        try {
            this.guis = this.cfg.load(file4);
        }
        catch (IOException ex5) {
            this.utils.log(Level.SEVERE, "Failed to load GUIs.yml file! Please send this stack trace to the developer!");
        }
        final File file5 = new File(this.getDataFolder(), "players.yml");
        this.copyResource(file5);
        try {
            this.playerStore = this.cfg.load(file5);
        }
        catch (IOException ex4) {
            this.utils.log(Level.SEVERE, "Failed to load players.yml file! Please send this stack trace to the developer.");
            ex4.printStackTrace();
        }
    }
    
    public void updateConfig() {
        if (this.config.getStringList("blocked-commands") == null || this.config.getStringList("blocked-commands").isEmpty()) {
            this.config.set("blocked-commands", (Object)new String[] { "^(/execute(.*)|/)(minecraft:)(ban(-ip)?|pardon(-ip)?|stop|reload)($|\\s.*)?" });
            this.utils.log("Added missing blocked-commands config option to the config.");
            this.saveConfig(this.config, "config.yml");
        }
        if (this.config.getString("ps-custom-command") == null || this.config.getString("ps-custom-command").isEmpty()) {
            this.config.set("ps-custom-command", (Object)"/playerserver");
            this.utils.log("Added missing ps-custom-command config option to the config.");
            this.saveConfig(this.config, "config.yml");
        }
        if (this.config.get("global-max-RAM") == null) {
            this.config.set("global-max-RAM", (Object)(-1));
            this.utils.log("Added missing global-max-RAM config option to the config.");
            this.saveConfig(this.config, "config.yml");
        }
        if (this.config.get("global-max-servers") == null || this.config.getInt("global-max-servers") < -1) {
            this.config.set("global-max-servers", (Object)(-1));
            this.utils.log("Added missing global-max-servers config option to the config.");
            this.saveConfig(this.config, "config.yml");
        }
        if (this.config.get("default-expiry-days") != null) {
            this.config.getInt("default-expiry-days");
            this.config.set("default-expiry-days", (Object)null);
            this.utils.log("Removed default-expiry-days setting from config.");
            this.saveConfig(this.config, "config.yml");
        }
        if (this.config.get("always-op") == null) {
            this.config.set("always-op", (Object)Arrays.asList("Notch", "069a79f4-44e9-4726-a5be-fca90e38aaf5"));
            this.utils.log("Added default always-op list to existing config.");
            this.saveConfig(this.config, "config.yml");
        }
        if (this.config.get("reset-expiry-on-create") == null) {
            this.config.set("reset-expiry-on-create", (Object)false);
            this.utils.log("Added default reset-expiry-on-create to existing config.");
            this.saveConfig(this.config, "config.yml");
        }
        if (this.config.get("use-titles") == null) {
            this.config.set("use-titles", (Object)true);
            this.utils.log("Added default use-titles to existing config.");
            this.saveConfig(this.config, "config.yml");
        }
        if (this.config.get("purge-servers") == null) {
            this.config.set("purge-servers", (Object)false);
            this.utils.log("Added default purge-servers to existing config.");
            this.saveConfig(this.config, "config.yml");
        }
        if (this.config.get("purge-after") == null) {
            this.config.set("purge-after", (Object)"30 days");
            this.utils.log("Added default purge-after to existing config.");
            this.saveConfig(this.config, "config.yml");
        }
        if (this.config.get("purge-interval") == null) {
            this.config.set("purge-interval", (Object)"6 hours");
            this.utils.log("Added default purge-interval to existing config.");
            this.saveConfig(this.config, "config.yml");
        }
        if (this.config.get("wrapper") == null) {
            this.config.set("wrapper", (Object)"screen");
            this.utils.log("Added screen as 'wrapper' to existing config.");
            this.saveConfig(this.config, "config.yml");
        }
        if (this.config.get("wrapper-control-address") == null) {
            this.config.set("wrapper-control-address", (Object)"localhost");
            this.utils.log("Added default wrapper-control-address to existing config.");
            this.saveConfig(this.config, "config.yml");
        }
        if (this.config.get("wrapper-control-port") == null) {
            this.config.set("wrapper-control-port", (Object)5155);
            this.utils.log("Added default wrapper-control-port to existing config.");
            this.saveConfig(this.config, "config.yml");
        }
        if (this.config.get("online-join-delay") == null) {
            this.config.set("online-join-delay", (Object)3);
            this.utils.log("Added default online-join-delay to existing config.");
            this.saveConfig(this.config, "config.yml");
        }
        if (this.config.get("use-startup-queue") == null) {
            this.config.set("use-startup-queue", (Object)true);
            this.utils.log("Added default use-startup-queue to existing config.");
            this.saveConfig(this.config, "config.yml");
        }
        if (this.config.get("default-Xmx") != null) {
            this.defaultMem.put("xmx", this.config.getString("default-Xmx", "256M"));
            this.config.set("default-Xmx", (Object)null);
            this.utils.log("Removed default-Xmx setting from config. This is now set per-template in PlayerServers.yml");
            this.saveConfig(this.config, "config.yml");
        }
        if (this.config.get("default-Xms") != null) {
            this.defaultMem.put("xms", this.config.getString("default-Xms", "128M"));
            this.config.set("default-Xms", (Object)null);
            this.utils.log("Removed default-Xms setting from config. This is now set per-template in PlayerServers.yml");
            this.saveConfig(this.config, "config.yml");
        }
    }
    
    public void saveConfig(final Configuration configuration, final String s) {
        final File file = new File(this.getDataFolder(), s);
        try {
            this.cfg.save(configuration, file);
        }
        catch (IOException ex) {
            this.utils.log(Level.SEVERE, "Failed to save the file " + file.getPath() + ", please send this stack trace to the developer.");
            ex.printStackTrace();
        }
    }
    
    public void loadConfig() {
        this.debug = this.config.getBoolean("debug", false);
        this.psCommand = this.config.getString("ps-custom-command", "playerserver");
        if (this.psCommand.startsWith("/")) {
            this.psCommand = this.psCommand.substring(1);
        }
        this.blockedCmds = (List<String>)this.config.getStringList("blocked-commands");
        this.useExpiry = this.config.getBoolean("use-expire-dates", true);
        this.utils.debug("use-expire-dates: " + this.useExpiry);
        this.prefix = this.config.getString("prefix", "&b&oPlayrSrv &7&o»&f");
        this.utils.debug("prefix: " + this.prefix);
        if (this.config.getString("hub-server") == null || this.config.getString("hub-server").equals("default")) {
            final ProxyServer proxy = this.proxy;
            final ConfigurationAdapter configurationAdapter = ProxyServer.getInstance().getConfigurationAdapter();
            final String s = "default_server";
            final ProxyServer proxy2 = this.proxy;
            this.fallbackSrv = configurationAdapter.getString(s, ProxyServer.getInstance().getServers().values().iterator().next().getName());
        }
        else {
            this.fallbackSrv = this.config.getString("hub-server");
        }
        this.utils.debug("hub-server: " + this.fallbackSrv);
        if (this.config.getString("servers-folder").equals("default")) {
            this.serversFolder = this.getDataFolder().getAbsolutePath() + File.separator + "servers";
        }
        else {
            this.serversFolder = this.config.getString("servers-folder");
        }
        this.utils.debug("servers-folder: " + this.serversFolder);
        this.downloadsPort = this.config.getInt("downloads-port", 8080);
        this.utils.debug("downloads-port: " + this.downloadsPort);
        this.joinDelay = this.config.getInt("startup-join-delay", 10);
        this.onlineJoinDelay = this.config.getInt("online-join-delay", 3);
        this.utils.debug("config max servers = " + this.config.get("global-max-servers") + " | class =" + this.config.get("global-max-servers").getClass());
        this.globalMaxServers = this.config.getInt("global-max-servers");
        this.utils.debug("global-max-servers = " + this.globalMaxServers);
        if (this.config.get("global-max-RAM") instanceof Integer) {
            this.globalMaxRam = this.config.getInt("global-max-RAM");
        }
        else {
            this.globalMaxRam = this.utils.memStringToInt(this.config.getString("global-max-RAM"));
        }
        this.utils.debug("global-max-RAM = " + this.globalMaxRam);
        this.alwaysOP = (List<String>)this.config.getStringList("always-op");
        this.resetExpiry = this.config.getBoolean("reset-expiry-on-create");
        this.utils.debug("reset-expiry-on-create = " + this.resetExpiry);
        this.useTitles = this.config.getBoolean("use-titles");
        this.utils.debug("use-titles = " + this.useTitles);
        this.autoPurge = this.config.getBoolean("purge-servers");
        this.utils.debug("purge-servers = " + this.autoPurge);
        this.autoPurgeTime = this.expiryTracker.stringToMillis(this.config.getString("purge-after"));
        this.utils.debug("purge-after in milliseconds = " + this.autoPurgeTime);
        this.autoPurgeInterval = this.expiryTracker.stringToMillis(this.config.getString("purge-interval"));
        this.utils.debug("purge-interval in milliseconds = " + this.autoPurgeInterval);
        this.wrapper = this.config.getString("wrapper");
        if (this.wrapper.matches("(?i)(scr(e*)n)")) {
            this.wrapper = "screen";
        }
        else if (this.wrapper.matches("(?i)(tm(u)?x)")) {
            this.wrapper = "tmux";
        }
        else if (this.wrapper.matches("(?i)(r(e)?m(o)?t(e)?)")) {
            this.wrapper = "remote";
        }
        else {
            this.wrapper = "default";
        }
        this.utils.debug("wrapper = " + this.wrapper);
        this.wrapperPort = this.config.getInt("wrapper-control-port");
        this.utils.debug("wrapper-control-port = " + this.wrapperPort);
        this.wrapperAddress = this.config.getString("wrapper-control-address");
        this.utils.debug("wrapper-control-address = " + this.wrapperAddress);
        this.useQueue = this.config.getBoolean("use-startup-queue");
        this.utils.debug("use-startup-queue = " + this.useQueue);
    }
    
    public void loadGUIs() {
        this.updateGUIs();
        final String s = "¶¶¶";
        final String s2 = "æææ";
        final String s3 = "%#%";
        final String s4 = "#%#";
        final String s5 = "#@#";
        final String s6 = "@@@";
        final StringBuilder sb = new StringBuilder();
        sb.append("go-back-item").append(s3).append((this.guis.get("go-back-item") == null) ? "stained_glass_pane:14" : this.guis.get("go-back-item")).append(s);
        sb.append("fill-item").append(s3).append((this.guis.get("fill-item") == null) ? "stained_glass_pane:0" : this.guis.get("fill-item")).append(s);
        sb.append("settings-title").append(s3).append((this.guis.get("settings-title") == null) ? "&5&lSettings &0&l»" : this.guis.get("settings-title")).append(s);
        sb.append("settings-icons").append(s3);
        if (this.guis.get("settings-icons") instanceof HashMap) {
            for (final Map.Entry<String, V> entry : ((HashMap)this.guis.get("settings-icons")).entrySet()) {
                sb.append(entry.getKey()).append(s4);
                for (final Map.Entry<String, V> entry2 : ((HashMap)entry.getValue()).entrySet()) {
                    sb.append(entry2.getKey()).append(s5).append((String)entry2.getValue()).append(s6);
                }
                if (sb.substring(sb.length() - 3, sb.length()).matches(s6)) {
                    sb.delete(sb.length() - 3, sb.length());
                }
                sb.append(s2);
            }
        }
        else {
            for (final String s7 : new String[] { "gamemode", "difficulty", "pvp-off", "pvp-on", "whitelist", "player-manager", "world-settings", "expire-tracker" }) {
                sb.append(s7).append(s4);
                sb.append("item-id").append(s5).append("bedrock").append(s6);
                sb.append("item-name").append(s5).append("&e&o").append(s7).append(s6);
                sb.append("item-lore").append(s5).append("&7&o(Error loading GUI items)").append(s6);
                if (sb.substring(sb.length() - 3, sb.length()).matches(s6)) {
                    sb.delete(sb.length() - 3, sb.length());
                }
                sb.append(s2);
            }
        }
        if (sb.substring(sb.length() - 3, sb.length()).matches(s2)) {
            sb.delete(sb.length() - 3, sb.length());
        }
        sb.append(s);
        sb.append("gamemode-title").append(s3).append((this.guis.get("gamemode-title") == null) ? "&5&lServer Gamemode &0&l»" : this.guis.get("gamemode-title")).append(s);
        sb.append("gamemode-icons").append(s3);
        if (this.guis.get("gamemode-icons") instanceof HashMap) {
            for (final Map.Entry<String, V> entry3 : ((HashMap)this.guis.get("gamemode-icons")).entrySet()) {
                sb.append(entry3.getKey()).append(s4);
                for (final Map.Entry<String, V> entry4 : ((HashMap)entry3.getValue()).entrySet()) {
                    sb.append(entry4.getKey()).append(s5).append((String)entry4.getValue()).append(s6);
                }
                if (sb.substring(sb.length() - 3, sb.length()).matches(s6)) {
                    sb.delete(sb.length() - 3, sb.length());
                }
                sb.append(s2);
            }
        }
        else {
            for (final String s8 : new String[] { "force-gamemode-on", "force-gamemode-off", "survival", "creative", "adventure", "spectator" }) {
                sb.append(s8).append(s4);
                sb.append("item-id").append(s5).append("bedrock").append(s6);
                sb.append("item-name").append(s5).append("&e&o").append(s8).append(s6);
                sb.append("item-lore").append(s5).append("&7&o(Error loading GUI items)").append(s6);
                if (sb.substring(sb.length() - 3, sb.length()).matches(s6)) {
                    sb.delete(sb.length() - 3, sb.length());
                }
                sb.append(s2);
            }
        }
        if (sb.substring(sb.length() - 3, sb.length()).matches(s2)) {
            sb.delete(sb.length() - 3, sb.length());
        }
        sb.append(s);
        sb.append("difficulty-title").append(s3).append((this.guis.get("difficulty-title") == null) ? "&5&lDifficulty &0&l»" : this.guis.get("difficulty-title")).append(s);
        sb.append("difficulty-icons").append(s3);
        if (this.guis.get("difficulty-icons") instanceof HashMap) {
            for (final Map.Entry<String, V> entry5 : ((HashMap)this.guis.get("difficulty-icons")).entrySet()) {
                sb.append(entry5.getKey()).append(s4);
                for (final Map.Entry<String, V> entry6 : ((HashMap)entry5.getValue()).entrySet()) {
                    sb.append(entry6.getKey()).append(s5).append((String)entry6.getValue()).append(s6);
                }
                if (sb.substring(sb.length() - 3, sb.length()).matches(s6)) {
                    sb.delete(sb.length() - 3, sb.length());
                }
                sb.append(s2);
            }
        }
        else {
            for (final String s9 : new String[] { "peaceful", "easy", "normal", "hard" }) {
                sb.append(s9).append(s4);
                sb.append("item-id").append(s5).append("bedrock").append(s6);
                sb.append("item-name").append(s5).append("&e&o").append(s9).append(s6);
                sb.append("item-lore").append(s5).append("&7&o(Error loading GUI items)").append(s6);
                if (sb.substring(sb.length() - 3, sb.length()).matches(s6)) {
                    sb.delete(sb.length() - 3, sb.length());
                }
                sb.append(s2);
            }
        }
        if (sb.substring(sb.length() - 3, sb.length()).matches(s2)) {
            sb.delete(sb.length() - 3, sb.length());
        }
        sb.append(s);
        sb.append("whitelist-title").append(s3).append((this.guis.get("whitelist-title") == null) ? "&5&lWhitelisting &0&l»" : this.guis.get("whitelist-title")).append(s);
        sb.append("whitelist-icons").append(s3);
        if (this.guis.get("whitelist-icons") instanceof HashMap) {
            for (final Map.Entry<String, V> entry7 : ((HashMap)this.guis.get("whitelist-icons")).entrySet()) {
                sb.append(entry7.getKey()).append(s4);
                for (final Map.Entry<String, V> entry8 : ((HashMap)entry7.getValue()).entrySet()) {
                    sb.append(entry8.getKey()).append(s5).append((String)entry8.getValue()).append(s6);
                }
                if (sb.substring(sb.length() - 3, sb.length()).matches(s6)) {
                    sb.delete(sb.length() - 3, sb.length());
                }
                sb.append(s2);
            }
        }
        else {
            for (final String s10 : new String[] { "whitelist-off", "whitelist-on", "current-whitelist", "add-player", "remove-player", "clear-whitelist" }) {
                sb.append(s10).append(s4);
                sb.append("item-id").append(s5).append("bedrock").append(s6);
                sb.append("item-name").append(s5).append("&e&o").append(s10).append(s6);
                sb.append("item-lore").append(s5).append("&7&o(Error loading GUI items)").append(s6);
                if (sb.substring(sb.length() - 3, sb.length()).matches(s6)) {
                    sb.delete(sb.length() - 3, sb.length());
                }
                sb.append(s2);
            }
        }
        if (sb.substring(sb.length() - 3, sb.length()).matches(s2)) {
            sb.delete(sb.length() - 3, sb.length());
        }
        sb.append(s);
        sb.append("player-manager-title").append(s3).append((this.guis.get("player-manager-title") == null) ? "&5&lPlayers Manager &0&l»" : this.guis.get("player-manager-title")).append(s);
        sb.append("player-manager-icons").append(s3);
        if (this.guis.get("player-manager-icons") instanceof HashMap) {
            for (final Map.Entry<String, V> entry9 : ((HashMap)this.guis.get("player-manager-icons")).entrySet()) {
                sb.append(entry9.getKey()).append(s4);
                for (final Map.Entry<String, V> entry10 : ((HashMap)entry9.getValue()).entrySet()) {
                    sb.append(entry10.getKey()).append(s5).append((String)entry10.getValue()).append(s6);
                }
                if (sb.substring(sb.length() - 3, sb.length()).matches(s6)) {
                    sb.delete(sb.length() - 3, sb.length());
                }
                sb.append(s2);
            }
        }
        else {
            for (final String s11 : new String[] { "nobody-online", "player", "page-back", "page-forward" }) {
                sb.append(s11).append(s4);
                sb.append("item-id").append(s5).append("bedrock").append(s6);
                sb.append("item-name").append(s5).append("&e&o").append(s11).append(s6);
                sb.append("item-lore").append(s5).append("&7&o(Error loading GUI items)").append(s6);
                if (sb.substring(sb.length() - 3, sb.length()).matches(s6)) {
                    sb.delete(sb.length() - 3, sb.length());
                }
                sb.append(s2);
            }
        }
        if (sb.substring(sb.length() - 3, sb.length()).matches(s2)) {
            sb.delete(sb.length() - 3, sb.length());
        }
        sb.append(s);
        sb.append("player-title").append(s3).append((this.guis.get("player-title") == null) ? "&5&lPlayer &0&l»" : this.guis.get("player-title")).append(s);
        sb.append("player-icons").append(s3);
        if (this.guis.get("player-icons") instanceof HashMap) {
            for (final Map.Entry<String, V> entry11 : ((HashMap)this.guis.get("player-icons")).entrySet()) {
                sb.append(entry11.getKey()).append(s4);
                for (final Map.Entry<String, V> entry12 : ((HashMap)entry11.getValue()).entrySet()) {
                    sb.append(entry12.getKey()).append(s5).append((String)entry12.getValue()).append(s6);
                }
                if (sb.substring(sb.length() - 3, sb.length()).matches(s6)) {
                    sb.delete(sb.length() - 3, sb.length());
                }
                sb.append(s2);
            }
        }
        else {
            for (final String s12 : new String[] { "kick", "ban", "ban-confirm", "player-is-whitelisted", "player-not-whitelisted" }) {
                sb.append(s12).append(s4);
                sb.append("item-id").append(s5).append("bedrock").append(s6);
                sb.append("item-name").append(s5).append("&e&o").append(s12).append(s6);
                sb.append("item-lore").append(s5).append("&7&o(Error loading GUI items)").append(s6);
                if (sb.substring(sb.length() - 3, sb.length()).matches(s6)) {
                    sb.delete(sb.length() - 3, sb.length());
                }
                sb.append(s2);
            }
        }
        if (sb.substring(sb.length() - 3, sb.length()).matches(s2)) {
            sb.delete(sb.length() - 3, sb.length());
        }
        sb.append(s);
        sb.append("world-settings-title").append(s3).append((this.guis.get("world-settings-title") == null) ? "&5&lWorld Settings &0&l»" : this.guis.get("world-settings-title")).append(s);
        sb.append("world-settings-icons").append(s3);
        if (this.guis.get("world-settings-icons") instanceof HashMap) {
            for (final Map.Entry<String, V> entry13 : ((HashMap)this.guis.get("world-settings-icons")).entrySet()) {
                sb.append(entry13.getKey()).append(s4);
                for (final Map.Entry<String, V> entry14 : ((HashMap)entry13.getValue()).entrySet()) {
                    sb.append(entry14.getKey()).append(s5).append((String)entry14.getValue()).append(s6);
                }
                if (sb.substring(sb.length() - 3, sb.length()).matches(s6)) {
                    sb.delete(sb.length() - 3, sb.length());
                }
                sb.append(s2);
            }
        }
        else {
            for (final String s13 : new String[] { "allow-nether-on", "allow-nether-off", "allow-flight-on", "allow-flight-off", "generate-structures-on", "generate-structures-off", "mob-settings" }) {
                sb.append(s13).append(s4);
                sb.append("item-id").append(s5).append("bedrock").append(s6);
                sb.append("item-name").append(s5).append("&e&o").append(s13).append(s6);
                sb.append("item-lore").append(s5).append("&7&o(Error loading GUI items)").append(s6);
                if (sb.substring(sb.length() - 3, sb.length()).matches(s6)) {
                    sb.delete(sb.length() - 3, sb.length());
                }
                sb.append(s2);
            }
        }
        if (sb.substring(sb.length() - 3, sb.length()).matches(s2)) {
            sb.delete(sb.length() - 3, sb.length());
        }
        sb.append(s);
        sb.append("mob-settings-title").append(s3).append((this.guis.get("mob-settings-title") == null) ? "&5&lMob Settings &0&l»" : this.guis.get("mob-settings-title")).append(s);
        sb.append("mob-settings-icons").append(s3);
        if (this.guis.get("mob-settings-icons") instanceof HashMap) {
            for (final Map.Entry<String, V> entry15 : ((HashMap)this.guis.get("mob-settings-icons")).entrySet()) {
                sb.append(entry15.getKey()).append(s4);
                for (final Map.Entry<String, V> entry16 : ((HashMap)entry15.getValue()).entrySet()) {
                    sb.append(entry16.getKey()).append(s5).append((String)entry16.getValue()).append(s6);
                }
                if (sb.substring(sb.length() - 3, sb.length()).matches(s6)) {
                    sb.delete(sb.length() - 3, sb.length());
                }
                sb.append(s2);
            }
        }
        else {
            for (final String s14 : new String[] { "monster-spawns-on", "monster-spawns-off", "animal-spawns-on", "animal-spawns-off", "npc-spawns-on", "npc-spawns-off" }) {
                sb.append(s14).append(s4);
                sb.append("item-id").append(s5).append("bedrock").append(s6);
                sb.append("item-name").append(s5).append("&e&o").append(s14).append(s6);
                sb.append("item-lore").append(s5).append("&7&o(Error loading GUI items)").append(s6);
                if (sb.substring(sb.length() - 3, sb.length()).matches(s6)) {
                    sb.delete(sb.length() - 3, sb.length());
                }
                sb.append(s2);
            }
        }
        if (sb.substring(sb.length() - 3, sb.length()).matches(s2)) {
            sb.delete(sb.length() - 3, sb.length());
        }
        sb.append(s);
        sb.append("servers-title").append(s3).append((this.guis.get("servers-title") == null) ? "&5&lPlayerServers &0&l»" : this.guis.get("servers-title")).append(s);
        sb.append("servers-icons").append(s3);
        if (this.guis.get("servers-icons") instanceof HashMap) {
            for (final Map.Entry<String, V> entry17 : ((HashMap)this.guis.get("servers-icons")).entrySet()) {
                sb.append(entry17.getKey()).append(s4);
                for (final Map.Entry<String, V> entry18 : ((HashMap)entry17.getValue()).entrySet()) {
                    sb.append(entry18.getKey()).append(s5).append((String)entry18.getValue()).append(s6);
                }
                if (sb.substring(sb.length() - 3, sb.length()).matches(s6)) {
                    sb.delete(sb.length() - 3, sb.length());
                }
                sb.append(s2);
            }
        }
        else {
            for (final String s15 : new String[] { "none-online", "server", "page-back", "page-forward" }) {
                sb.append(s15).append(s4);
                sb.append("item-id").append(s5).append("bedrock").append(s6);
                sb.append("item-name").append(s5).append("&e&o").append(s15).append(s6);
                sb.append("item-lore").append(s5).append("&7&o(Error loading GUI items)").append(s6);
                if (sb.substring(sb.length() - 3, sb.length()).matches(s6)) {
                    sb.delete(sb.length() - 3, sb.length());
                }
                sb.append(s2);
            }
        }
        if (sb.substring(sb.length() - 3, sb.length()).matches(s2)) {
            sb.delete(sb.length() - 3, sb.length());
        }
        sb.append(s);
        sb.append("templates-title").append(s3).append((this.guis.get("templates-title") == null) ? "&5&lWorlds & Templates &0&l»" : this.guis.get("templates-title")).append(s);
        sb.append("templates-icons").append(s3);
        if (this.guis.get("templates-icons") instanceof HashMap) {
            for (final Map.Entry<String, V> entry19 : ((HashMap)this.guis.get("templates-icons")).entrySet()) {
                sb.append(entry19.getKey()).append(s4);
                for (final Map.Entry<String, V> entry20 : ((HashMap)entry19.getValue()).entrySet()) {
                    sb.append(entry20.getKey()).append(s5).append((String)entry20.getValue()).append(s6);
                }
                if (sb.substring(sb.length() - 3, sb.length()).matches(s6)) {
                    sb.delete(sb.length() - 3, sb.length());
                }
                sb.append(s2);
            }
        }
        else {
            for (final String s16 : new String[] { "page-back", "page-forward" }) {
                sb.append(s16).append(s4);
                sb.append("item-id").append(s5).append("bedrock").append(s6);
                sb.append("item-name").append(s5).append("&e&o").append(s16).append(s6);
                sb.append("item-lore").append(s5).append("&7&o(Error loading GUI items)").append(s6);
                if (sb.substring(sb.length() - 3, sb.length()).matches(s6)) {
                    sb.delete(sb.length() - 3, sb.length());
                }
                sb.append(s2);
            }
        }
        if (sb.substring(sb.length() - 3, sb.length()).matches(s2)) {
            sb.delete(sb.length() - 3, sb.length());
        }
        sb.append(s);
        sb.append("control-title").append(s3).append((this.guis.get("control-title") == null) ? "&5&lPS Control &0&l»" : this.guis.get("control-title")).append(s);
        sb.append("control-icons").append(s3);
        if (this.guis.get("control-icons") instanceof HashMap) {
            for (final Map.Entry<String, V> entry21 : ((HashMap)this.guis.get("control-icons")).entrySet()) {
                sb.append(entry21.getKey()).append(s4);
                for (final Map.Entry<String, V> entry22 : ((HashMap)entry21.getValue()).entrySet()) {
                    sb.append(entry22.getKey()).append(s5).append((String)entry22.getValue()).append(s6);
                }
                if (sb.substring(sb.length() - 3, sb.length()).matches(s6)) {
                    sb.delete(sb.length() - 3, sb.length());
                }
                sb.append(s2);
            }
        }
        else {
            for (final String s17 : new String[] { "expire-tracker", "create-server", "delete-server", "delete-confirm", "join-server", "start-server", "stop-server" }) {
                sb.append(s17).append(s4);
                sb.append("item-id").append(s5).append("bedrock").append(s6);
                sb.append("item-name").append(s5).append("&e&o").append(s17).append(s6);
                sb.append("item-lore").append(s5).append("&7&o(Error loading GUI items)").append(s6);
                if (sb.substring(sb.length() - 3, sb.length()).matches(s6)) {
                    sb.delete(sb.length() - 3, sb.length());
                }
                sb.append(s2);
            }
        }
        if (sb.substring(sb.length() - 3, sb.length()).matches(s2)) {
            sb.delete(sb.length() - 3, sb.length());
        }
        this.sender.guisSerialized = sb.toString();
    }
    
    public void updateGUIs() {
        boolean b = false;
        if (this.guis.get("settings-icons") instanceof HashMap && ((HashMap)this.guis.get("settings-icons")).get("expire-tracker") == null) {
            final HashMap<String, String> hashMap = new HashMap<String, String>();
            hashMap.put("item-id", "watch");
            hashMap.put("item-name", "&e&o&lTime Until Server Expires:");
            hashMap.put("item-lore", "Time Left: %time-left%||Expire Date: %expire-date%");
            this.utils.debug("updating GUI: settings with expire-tracker: " + hashMap.toString());
            ((HashMap)this.guis.get("settings-icons")).put("expire-tracker", hashMap);
            b = true;
        }
        if (this.guis.get("control-title") == null) {
            this.guis.set("control-title", (Object)"&5&lPS Control &0&l»");
            b = true;
        }
        if (this.guis.get("control-icons") == null) {
            final HashMap<String, HashMap> hashMap2 = new HashMap<String, HashMap>();
            final HashMap<String, String> hashMap3 = new HashMap<String, String>();
            hashMap3.put("item-id", "watch");
            hashMap3.put("item-name", "&e&o&lTime Until Server Expires:");
            hashMap3.put("item-lore", "Time Left: %time-left%||Expire Date: %expire-date%");
            hashMap2.put("expire-tracker", (HashMap)hashMap3.clone());
            final HashMap<String, String> hashMap4 = new HashMap<String, String>();
            hashMap4.put("item-id", "emerald_block");
            hashMap4.put("item-name", "&a&o&lCreate a Server");
            hashMap4.put("item-lore", "You do not have a server,||click here to create one!");
            hashMap2.put("create-server", (HashMap)hashMap4.clone());
            final HashMap<String, String> hashMap5 = new HashMap<String, String>();
            hashMap5.put("item-id", "redstone_block");
            hashMap5.put("item-name", "&c&o&lDelete your server");
            hashMap5.put("item-lore", "You have a server,||click here to delete it!||You will have to confirm!");
            hashMap2.put("delete-server", (HashMap)hashMap5.clone());
            final HashMap<String, String> hashMap6 = new HashMap<String, String>();
            hashMap6.put("item-id", "tnt");
            hashMap6.put("item-name", "&c&lCONFIRM Server Delete!");
            hashMap6.put("item-lore", "&c&lWarning: Clicking this will||&c&lpermanently delete your server!");
            hashMap2.put("delete-confirm", (HashMap)hashMap6.clone());
            final HashMap<String, String> hashMap7 = new HashMap<String, String>();
            hashMap7.put("item-id", "compass");
            hashMap7.put("item-name", "&a&lJoin Your Server");
            hashMap7.put("item-lore", "Click to join your server!");
            hashMap2.put("join-server", (HashMap)hashMap7.clone());
            final HashMap<String, String> hashMap8 = new HashMap<String, String>();
            hashMap8.put("item-id", "diamond");
            hashMap8.put("item-name", "&b&lStart Your Server");
            hashMap8.put("item-lore", "Click to start your server!");
            hashMap2.put("start-server", (HashMap)hashMap8.clone());
            final HashMap<String, String> hashMap9 = new HashMap<String, String>();
            hashMap9.put("item-id", "coal");
            hashMap9.put("item-name", "&c&lStop Your Server");
            hashMap9.put("item-lore", "Click to stop your server!");
            hashMap2.put("stop-server", (HashMap)hashMap9.clone());
            final HashMap<String, String> hashMap10 = new HashMap<String, String>();
            hashMap10.put("item-id", "compass");
            hashMap10.put("item-name", "&c&lLeave Your Server");
            hashMap10.put("item-lore", "Click to leave your server!");
            hashMap2.put("leave-server", (HashMap)hashMap10.clone());
            this.guis.set("control-icons", (Object)hashMap2);
            b = true;
        }
        if (((HashMap)this.guis.get("servers-icons")).get("server").get("item-lore").equals("Click to join this Player Server.")) {
            ((HashMap)this.guis.get("servers-icons")).get("server").put("item-lore", "Owner: %player%||Players: %current-players%/%max-players%||UUID: %player-uuid%||MOTD: %motd%||Template: %template-name%||Expire Date: %expire-date%||Time Left: %time-left%||Whitelist: %whitelist%");
            b = true;
        }
        if (b) {
            this.saveConfig(this.guis, "guis.yml");
            this.utils.debug("Saved updated guis.yml file.");
        }
    }
    
    public void loadMsgs() {
        this.utils.debug("messages class: " + this.messages.get("messages").getClass());
        if (this.messages.get("messages") instanceof HashMap) {
            this.msgMap.putAll((Map<? extends String, ? extends String>)this.messages.get("messages"));
        }
        this.updateMsgs();
    }
    
    public void updateMsgs() {
        final HashMap<String, String> hashMap = new HashMap<String, String>();
        hashMap.put("max-memory-changed", "&a%server-owner%'s server maximum memory set to %max-mem%||&aThis will take effect on next restart.");
        hashMap.put("start-memory-changed", "&a%server-owner%'s server starting memory set to %start-mem%||&aThis will take effect on next restart.");
        hashMap.put("invalid-memory-format", "&cInvalid memory format. Valid format examples: 512M, 1G, 1024M");
        hashMap.put("start-greater-max", "&cStart memory must be less than or equal to max memory.");
        hashMap.put("max-lessthan-start", "&cMax memory must be greater than or equal to the start memory.");
        hashMap.put("stopping-all-servers", "&6&lShutting down all player servers...");
        hashMap.put("no-template-specified", "&cNo template specified to create a server from!");
        hashMap.put("template-doesnt-exist", "&cThe specified template does not exist.");
        hashMap.put("no-templates-found", "&cNo templates were found in the templates folder!");
        hashMap.put("available-templates", "&b&oAvailable server templates:");
        hashMap.put("max-memory-reached", "&cMemory limit reached, try again later!");
        hashMap.put("max-servers-reached", "&cServer limit reached, try again later!");
        hashMap.put("invalid-time-unit", "&cInvalid time unit. &eValid units: ||&e&oMonths, Weeks, Days, Hours, Minutes");
        hashMap.put("no-template-permissions", "&c&oYou do not have permissions to use this template!");
        hashMap.put("invalid-slot-count", "&cSlot count must be a number greater than 0!");
        hashMap.put("max-players-count", "&a%server-owner%'s server max player count set to %slot-count%");
        hashMap.put("added-to-queue", "&aServer added to the startup queue, your server will start when a slot is available.");
        hashMap.put("queue-startup", "&b&lIt's your turn in the queue, starting up %server-owner%'s server!");
        hashMap.put("removed-from-queue", "&cYou've been removed from the startup queue!");
        hashMap.put("create-copying-files", "&e&oCopying %template-name% &e&oTemplate & Modifying settings...");
        hashMap.put("create-failed-copy", "&cFailed to copy server files for template: %template-name%");
        hashMap.put("create-missing-template", "&c%template-name% &cdoesn't exist!");
        hashMap.put("finish-delete-problem", "&c&lUh oh, something went wrong while deleting the server! It might have been deleted already.");
        hashMap.put("check-expire-times", "&e&oYour server will expire in %time-left%, on %expire-date%.");
        hashMap.put("check-expire-unlimited", "&e&oYou have unlimited server time!");
        hashMap.put("gamemode-changed", "&aDefault Gamemode set to &o%gamemode%!");
        hashMap.put("force-gamemode-on", "&aForce gamemode &2&oON||&e&oThis will take effect on next server restart!");
        hashMap.put("force-gamemode-off", "&aForce gamemode &c&oOFF||&e&oThis will take effect on next server restart!");
        hashMap.put("difficulty-changed", "&aServer difficulty set to &2&l&o%difficulty%!");
        hashMap.put("whitelist-enabled", "&eServer Whitelist: &aON");
        hashMap.put("whitelist-disabled", "&eServer Whitelist: &cOFF");
        hashMap.put("whitelist-add-timeout", "&c&oWhoops! &e&oTime ran out waiting for your input! Try again.");
        hashMap.put("whitelist-add-cancelled", "&c&oCancelled.");
        hashMap.put("whitelist-modify-instructions", "&aPlease type the player's name or UUID in chat &7&o(or 'cancel' to cancel):");
        hashMap.put("whitelist-cleared", "&c&lCleared the whitelist!");
        hashMap.put("whitelist-added", "&aAdded &o%player%&a to the whitelist.");
        hashMap.put("whitelist-removed", "&cRemoved &o%player%&c from the whitelist.");
        hashMap.put("monster-spawns-on", "&aMonster spawning set to &2&oTrue||&e&oThis will take effect on next server restart!");
        hashMap.put("monster-spawns-off", "&aMonster spawning set to &c&oFalse.||&e&oThis will take effect on next server restart!");
        hashMap.put("animal-spawns-on", "&aAnimal spawning set to &2&oTrue||&e&oThis will take effect on next server restart!");
        hashMap.put("animal-spawns-off", "&aAnimal spawning set to &c&oFalse.||&e&oThis will take effect on next server restart!");
        hashMap.put("npc-spawns-on", "&aVillager spawning set to &2&oTrue||&e&oThis will take effect on next server restart!");
        hashMap.put("npc-spawns-off", "&aVillager spawning set to &c&oFalse.||&e&oThis will take effect on next server restart!");
        hashMap.put("allow-nether-on", "&aAllow nether set to &a&oTrue||&e&oThis will take effect on next server restart!");
        hashMap.put("allow-nether-off", "&aAllow nether set to &c&oFalse||&e&oThis will take effect on next server restart!");
        hashMap.put("allow-flight-on", "&aAllow flight set to &a&oTrue||&e&oThis will take effect on next server restart!");
        hashMap.put("allow-flight-off", "&aAllow flight set to &c&oFalse||&e&oThis will take effect on next server restart!");
        hashMap.put("generate-structures-on", "&aGenerate structures set to &a&oTrue||&e&oThis will take effect on next server restart!");
        hashMap.put("generate-structures-off", "&aGenerate structures set to &c&oFalse||&e&oThis will take effect on next server restart!");
        hashMap.put("kicked-player", "&aYou have kicked &6&l%player% &afrom your server!");
        hashMap.put("got-kicked", "&e&oYou were kicked from this server by %player%");
        hashMap.put("unbanned-player", "&aYou have unbanned &6&l$%layer% &afrom your server!");
        hashMap.put("banned-player", "&aYou have banned &6&l$%layer% &afrom your server!");
        hashMap.put("got-banned", "&e&oYou were evicted! Reason: &c%reason% | &c&oEvicted by: &6%player%");
        hashMap.put("ban-message", "Eviction Reason: %reason% | Evicted by: %player%");
        hashMap.put("pvp-enabled", "&c&lPvP enabled in all worlds!");
        hashMap.put("pvp-disabled", "&a&lPvP disabled in all worlds!");
        hashMap.put("regain-info", "&c&lRelog to OP yourself, use &6&l/myserver regain if others are deOPing you.");
        hashMap.put("opped-player", "&a&lYou have promoted 6&l%player% &a&lto OP.");
        hashMap.put("deopped-player", "&a&lYou have promoted 6&l%player% &a&lto OP.");
        hashMap.put("must-be-online", "&cPlayer must be online to do that!");
        hashMap.put("leave-message", "&a'Til next time! &eSending you to '%server%'...");
        hashMap.put("motd-changed", "&e&o&lServer's MOTD changed to:||%motd%");
        hashMap.put("motd-display", "&e&o&lServer MOTD:||%motd%");
        hashMap.put("motd-too-long", "&cServer MOTDs are limited to 30 characters, not including color codes.");
        hashMap.put("help-ps-header", "&3&o%ps-command% (/ps) Help: &7&o<required> [optional]");
        hashMap.put("help-ps-join", "Join another player's server.");
        hashMap.put("help-ps-leave", "Leaves a player's server and sends you to the default server.");
        hashMap.put("help-ps-create", "Creates a server for you. Optionally specify the world/template to use.");
        hashMap.put("help-ps-home", "Starts and joins your server.");
        hashMap.put("help-ps-stop", "Stops your server.");
        hashMap.put("help-ps-delete", "Deletes your server.");
        hashMap.put("help-ps-motd", "View or set your server MOTD.");
        hashMap.put("help-ps-time", "Check how much time you have left on your server.");
        hashMap.put("help-ps-sharetime", "Share some of your expire time with another player.");
        hashMap.put("help-ps-worlds", "List the available setups.");
        hashMap.put("help-psa-header", "&b&oValid Commands for /playerserveradmin (/psa): &7&o<required> [optional]");
        hashMap.put("help-psa-create", "Creates a server for the player.");
        hashMap.put("help-psa-templates", "List the available templates");
        hashMap.put("help-psa-join", "Joins the specified player's server.");
        hashMap.put("help-psa-start", "Starts the specified player's server.");
        hashMap.put("help-psa-stop", "Stops the specified player's server.");
        hashMap.put("help-psa-delete", "Deletes the specified player's server. Add the 'confirm' argument to delete!");
        hashMap.put("help-psa-stopall", "Stops ALL currently running servers.");
        hashMap.put("help-psa-addtime", "Adds time to a player's server expiry time.");
        hashMap.put("help-psa-removetime", "Removes time from a player's server expiry time.");
        hashMap.put("help-psa-checktime", "Checks how much time a player has left.");
        hashMap.put("help-psa-maxmem", "Set the max memory for a player's server. Valid format ex: 512M, 1G, 1024M");
        hashMap.put("help-psa-startmem", "Set the max memory for a player's server. Valid format ex: 512M, 1G, 1024M");
        hashMap.put("help-psa-slots", "Set the max player slots for a player's server.");
        hashMap.put("help-psa-reload", "Reloads the bungee config.");
        hashMap.put("help-psa-motd", "View or set a player's server MOTD.");
        hashMap.put("help-mys-header", "&b&o/MyServer (/mys) Help:");
        hashMap.put("help-mys-settings", "Edit your server settings.");
        hashMap.put("help-mys-ban", "Ban or unban (evict) a player from your server.");
        hashMap.put("help-mys-kick", "Kick a player from your server.");
        hashMap.put("help-mys-whitelist", "Controls the whitelist of your server.");
        hashMap.put("help-mys-op", "OP or deOPs a player on your server.");
        hashMap.put("help-mys-regain", "Wipes OP list and regains control of your server");
        hashMap.put("help-mys-stop", "Stops your server. Restart with &6&l/ps home");
        hashMap.put("not-enough-time", "&cSorry, you do not have enough time to do this.");
        hashMap.put("no-share-unlimited", "&cSorry, you can't share unlimited server time!");
        hashMap.put("server-join-online-guest-title", "&a&o%server-owner%'s server online!||&eSending you now.");
        hashMap.put("server-join-offline-guest-title", "&c&oServer offline!||&eYou need to wait for the player to start it.");
        hashMap.put("server-join-online-owner-title", "&a&oServer online!||&eSending you there now.");
        hashMap.put("server-join-offline-owner-title", "&c&oServer offline!||&eStarting it up, this will just take a sec...");
        hashMap.put("server-stop-online-owner-title", "&e&oStopping your server");
        hashMap.put("server-stop-online-guest-title", "&cStopping %server-owner%'s server.");
        hashMap.put("server-stop-offline-owner-title", "&cYour server is not online!");
        hashMap.put("server-stop-offline-guest-title", "&c%server-owner%'s server is offline.");
        hashMap.put("other-server-not-online-title", "&c%server-owner%'s server offline!");
        hashMap.put("no-server-title", "&cYou do not have a server!");
        hashMap.put("other-no-server-title", "&cThis player does not have a server!");
        hashMap.put("server-expired-title", "&cSorry, server time expired!||&eYour server time has run out.");
        hashMap.put("max-memory-reached-title", "&cMemory limit reached||&eTry again later!");
        hashMap.put("max-servers-reached-title", "&cServer limit reached||&eTry again later!");
        hashMap.put("no-player-specified-title", "&cYou didn't specify a player!");
        hashMap.put("sent-fallback-title", "&aSent back to %fallback-server%!");
        hashMap.put("not-player-server-title", "&cYou aren't on a player server.");
        hashMap.put("template-doesnt-exist-title", "&cThe specified template does not exist.");
        hashMap.put("no-templates-found-title", "&cNo templates were found!");
        hashMap.put("create-start-title", "&b&oCreating your server!||&e&oThis may take a minute...");
        hashMap.put("have-server-title", "&aYou have a server!||&e&oStart and join it with &6&l/ps home");
        hashMap.put("delete-warning-title", "&c&lWARNING!||&c&l&k* &e&lREAD CHAT &c&l&k*");
        hashMap.put("recently-started-title", "&cPlease wait a minute.||&e&oYou recently started, stopped, or deleted your server.");
        hashMap.put("player-never-joined", "&cThis player has never joined the server.");
        hashMap.put("added-to-queue-title", "&aAdded to queue!||&eYour server will start when a slot is available.");
        hashMap.put("queue-startup-title", "&b&lYou are up next!||&eStarting up %server-owner%'s server.");
        hashMap.put("removed-from-queue-title", "&cRemoved from queue!||&eYou've been removed from the startup queue!");
        if (this.msgMap.containsKey("recently-started") && this.msgMap.get("recently-started").equalsIgnoreCase("&cYou recently started or stopped your server, please wait a minute.")) {
            this.msgMap.put("recently-started", "&cYou recently started, stopped, or deleted your server, please wait a minute.");
        }
        final Iterator<Map.Entry<String, String>> iterator = this.msgMap.entrySet().iterator();
        while (iterator.hasNext()) {
            final Map.Entry<String, String> entry = iterator.next();
            final String s = entry.getKey();
            String s2 = entry.getValue();
            if (s2.contains("%server-owners%")) {
                s2 = s2.replaceAll("%server-owners%", "%server-owner%");
                iterator.remove();
                hashMap.put(s, s2);
                this.utils.debug(s + ": fixed %server-owner% typo.");
            }
            if (s2.matches("(?i)(.*)(%days-changed%)(\\sday(s)?)?(.*)")) {
                s2 = s2.replaceAll("(?i)(%days-changed%)(\\sday(s)?)?", "%time-changed%");
                iterator.remove();
                hashMap.put(s, s2);
                this.utils.debug(s + ": updated existing %days-changed% placeholders to %time-changed%.");
            }
            if (s2.matches("(?i)(.*)(%days-left%)(\\sday(s)?)?(.*)")) {
                final String replaceAll = s2.replaceAll("(?i)(%days-left%)(\\sday(s)?)?", "%time-left%");
                iterator.remove();
                hashMap.put(s, replaceAll);
                this.utils.debug(s + ": updated existing %days-left% placeholders to %time-left%.");
            }
        }
        boolean b = false;
        if (hashMap.size() > 0) {
            for (final Map.Entry<String, String> entry2 : hashMap.entrySet()) {
                if (!this.msgMap.containsKey(entry2.getKey().toString())) {
                    this.msgMap.put(entry2.getKey(), entry2.getValue());
                    this.utils.debug(entry2.getKey() + ": saved changes.");
                    b = true;
                }
            }
        }
        if (b) {
            this.messages.set("messages", (Object)this.msgMap);
            this.saveConfig(this.messages, "messages.yml");
            this.utils.debug("Saved updated messages.yml file.");
        }
    }
    
    public void loadServers() {
        final File file = new File(this.getDataFolder() + File.separator + "servers");
        this.utils.debug("serverDir = " + file.toString());
        if (!file.exists()) {
            file.mkdir();
        }
        this.utils.debug("servers config class = " + this.serverStore.get("servers").getClass());
        this.serverManager.serverMap.clear();
        if (this.serverStore.get("servers") instanceof LinkedHashMap) {
            this.serverManager.serverMap = (LinkedHashMap<String, HashMap<String, String>>)this.serverStore.get("servers");
        }
        this.utils.log(this.serverManager.serverMap.size() + " player servers saved.");
    }
    
    public void loadOnlineServers() {
        if (!this.getDataFolder().exists()) {
            this.getDataFolder().mkdir();
        }
        final File file = new File(this.getDataFolder(), "online.yml");
        if (!file.exists()) {
            try {
                file.createNewFile();
                try (final InputStream resourceAsStream = this.getResourceAsStream("online.yml");
                     final FileOutputStream fileOutputStream = new FileOutputStream(file)) {
                    ByteStreams.copy(resourceAsStream, (OutputStream)fileOutputStream);
                }
            }
            catch (IOException ex) {
                throw new RuntimeException("Unable to create online servers file!", ex);
            }
        }
        try {
            this.online = this.cfg.load(file);
            this.serverManager.addedServers = (HashMap<String, HashMap<String, String>>)this.online.get("servers");
            if (this.serverManager.addedServers != null && !this.serverManager.addedServers.isEmpty()) {
                for (final String s : this.serverManager.addedServers.keySet()) {
                    this.serverManager.addBungee(s, this.serverManager.addedServers.get(s).get("address"), Integer.valueOf(this.serverManager.addedServers.get(s).get("port")), this.serverManager.addedServers.get(s).get("motd"), 1);
                }
            }
        }
        catch (IOException ex2) {
            ex2.printStackTrace();
        }
    }
    
    public void loadPermissions() {
        if (this.playerStore.get("permissions") == null) {
            this.playerStore.set("permissions", (Object)this.permMap);
            this.saveConfig(this.playerStore, "players.yml");
        }
        else {
            this.permMap.clear();
            if (this.playerStore.get("permissions") instanceof HashMap) {
                this.permMap = (HashMap<String, HashMap<String, String>>)this.playerStore.get("permissions");
            }
        }
        final HashMap<String, HashMap<String, String>> hashMap = new HashMap<String, HashMap<String, String>>();
        boolean b = false;
        for (final Map.Entry<String, HashMap<String, String>> entry : this.permMap.entrySet()) {
            final HashMap<String, String> hashMap2 = new HashMap<String, String>();
            for (final Map.Entry<String, String> entry2 : entry.getValue().entrySet()) {
                if (entry2.getValue().equalsIgnoreCase("true")) {
                    hashMap2.put(entry2.getKey(), entry2.getValue());
                }
                else {
                    b = true;
                }
            }
            if (hashMap2.size() > 0) {
                hashMap.put(entry.getKey(), hashMap2);
            }
        }
        if (b && !this.permMap.equals(hashMap)) {
            this.permMap.clear();
            this.permMap.putAll(hashMap);
            this.permMapChanged = true;
        }
    }
    
    public void savePermissions() {
        this.playerStore.set("permissions", (Object)this.permMap);
        this.proxy.getScheduler().runAsync((Plugin)this, (Runnable)new Runnable() {
            final /* synthetic */ File val$file = new File(PlayerServers.this.getDataFolder(), "players.yml");
            
            @Override
            public void run() {
                try {
                    PlayerServers.this.cfg.save(PlayerServers.this.playerStore, this.val$file);
                }
                catch (IOException ex) {
                    PlayerServers.this.utils.log(Level.SEVERE, "Failed to save permissions to player.yml file.");
                    ex.printStackTrace();
                }
                PlayerServers.this.permMapChanged = false;
            }
        });
    }
    
    public void loadPlayers() {
        if (this.onlineMode && this.playerStore.get("players") != null) {
            this.utils.log(Level.WARNING, "Removing all players from players.yml file, no need to store them anymore!");
            this.playerStore.set("players", (Object)null);
            final File file = new File(this.getDataFolder(), "players.yml");
            try {
                this.cfg.save(this.playerStore, file);
            }
            catch (IOException ex) {
                this.utils.log(Level.SEVERE, "Failed to save players to player.yml file.");
                ex.printStackTrace();
            }
        }
        if (!this.onlineMode) {
            this.playerMap.clear();
            if (this.playerStore.get("players") == null) {
                this.playerStore.set("players", (Object)this.playerMap);
                this.savePlayers();
            }
            if (this.playerStore.get("players") != null && this.playerStore.get("players") instanceof TreeMap) {
                this.playerMap = (TreeMap<String, String>)this.playerStore.get("players");
            }
            else if ((this.playerStore.get("players") != null && this.playerStore.get("players") instanceof HashMap) || this.playerStore.get("players") instanceof LinkedHashMap) {
                this.playerMap.putAll((Map<? extends String, ? extends String>)this.playerStore.get("players"));
            }
            else {
                this.utils.log(Level.SEVERE, "Invalid players.yml formatting!");
            }
            this.utils.log(this.playerMap.size() + " saved players loaded.");
        }
    }
    
    public void putPlayer(final String s, final String s2) {
        this.playerMap.put(s, s2);
        this.playerMapChanged = true;
    }
    
    public void savePlayers() {
        this.playerStore.set("players", (Object)this.playerMap);
        this.proxy.getScheduler().runAsync((Plugin)this, (Runnable)new Runnable() {
            final /* synthetic */ File val$file = new File(PlayerServers.this.getDataFolder(), "players.yml");
            
            @Override
            public void run() {
                try {
                    PlayerServers.this.cfg.save(PlayerServers.this.playerStore, this.val$file);
                }
                catch (IOException ex) {
                    PlayerServers.this.utils.log(Level.SEVERE, "Failed to save players to player.yml file.");
                    ex.printStackTrace();
                }
                PlayerServers.this.playerMapChanged = false;
            }
        });
    }
    
    public void copyResource(final File file) {
        if (!file.exists()) {
            try {
                file.createNewFile();
                try {
                    ByteStreams.copy(this.getResourceAsStream(file.getName()), (OutputStream)new FileOutputStream(file));
                }
                catch (IOException ex) {
                    this.utils.log(Level.SEVERE, "Failed to copy the resource file " + file.getPath() + "! Please send this stack trace to the developer.");
                    ex.printStackTrace();
                }
            }
            catch (IOException ex2) {
                this.utils.log(Level.SEVERE, "Failed to create the resource file " + file.getPath() + "! Please send this stack trace to the developer.");
                ex2.printStackTrace();
            }
        }
    }
    
    public void setupScripts() {
        final File file = new File(this.getDataFolder() + File.separator + "scripts");
        this.utils.debug("scriptsDir = " + file.toString());
        if (!file.exists()) {
            file.mkdir();
        }
        this.copyResource(new File(this.getDataFolder(), "scripts" + File.separator + "PSWrapper.jar"));
    }
    
    public static PlayerServersAPI getApi() {
        return PlayerServers.api;
    }
    
    public PlayerServers getInstance() {
        return this;
    }
}
