package net.cakemine.playerservers.bukkit.commands;

import net.cakemine.playerservers.bukkit.*;
import net.cakemine.playerservers.bukkit.sync.*;
import org.bukkit.command.*;
import org.bukkit.*;
import org.bukkit.entity.*;

public class Sync implements CommandExecutor
{
    PlayerServers pl;
    PluginSender pSend;
    
    public Sync(final PlayerServers pl) {
        this.pl = pl;
        this.pSend = new PluginSender(this.pl);
    }
    
    public boolean onCommand(final CommandSender commandSender, final Command command, final String s, final String[] array) {
        if (commandSender instanceof ConsoleCommandSender || commandSender.isOp()) {
            if (Bukkit.getOnlinePlayers().size() > 0) {
                this.pl.templates.clear();
                this.pl.messages.clear();
                this.pSend.doSync(Bukkit.getOnlinePlayers().iterator().next());
            }
            else {
                this.pl.utils.sendMsg(commandSender, "&c&lThere must be at least one player on this server to forward commands!||&c&lThis is a limitation of plugin messaging channels.");
                this.pl.listener.syncDone = false;
            }
        }
        return true;
    }
}
