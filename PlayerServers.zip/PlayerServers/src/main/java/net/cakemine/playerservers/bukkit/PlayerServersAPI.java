package net.cakemine.playerservers.bukkit;

import org.bukkit.*;
import org.bukkit.entity.*;
import net.cakemine.playerservers.bukkit.gui.*;
import org.bukkit.inventory.*;
import java.util.*;
import org.bukkit.enchantments.*;
import java.io.*;
import com.google.common.io.*;

public final class PlayerServersAPI
{
    PlayerServers pl;
    public List<String> customGuis;
    
    PlayerServersAPI(final PlayerServers pl) {
        this.customGuis = new ArrayList<String>();
        this.pl = pl;
    }
    
    public final void reSync() {
        this.pl.sender.doSync();
    }
    
    public final boolean getDebugMode() {
        return this.pl.debug;
    }
    
    public final void debugLog(final String s) {
        this.pl.utils.debug(s);
    }
    
    public final String getPluginPrefix() {
        return this.pl.prefix;
    }
    
    public final void setPluginPrefix(final String prefix) {
        this.pl.prefix = prefix;
    }
    
    public final UUID getServerOwnerId() {
        return UUID.fromString(this.pl.utils.getOwnerId());
    }
    
    public final String getServerOwnerName() {
        return Bukkit.getOfflinePlayer(this.getServerOwnerId()).getName();
    }
    
    public final String getPlayerServerName() {
        return this.pl.getServer().getServerName();
    }
    
    public final int getPlayerServerPort() {
        return this.pl.getServer().getPort();
    }
    
    public final boolean isOwnerOP() {
        return this.pl.getOPCheck();
    }
    
    public final void setOwnerOP(final boolean b) {
        this.pl.psrvCfg.set("creator-gets-op", (Object)b);
        this.pl.saveConfig(this.pl.psrvCfg, this.pl.psrv);
    }
    
    public final boolean isExpireShutdown() {
        return this.pl.expireShutdown;
    }
    
    public final void setExpireShutdown(final boolean b) {
        this.pl.psrvCfg.set("shutdown-on-expire", (Object)true);
        this.pl.saveConfig(this.pl.psrvCfg, this.pl.psrv);
    }
    
    public final String getTemplateName() {
        return this.pl.psrvCfg.getString("template-name");
    }
    
    public final String getTemplateDescription() {
        return this.pl.psrvCfg.getString("description");
    }
    
    public final List<String> getTemplateDescriptionList() {
        return Arrays.asList(this.pl.psrvCfg.getString("description").split("||"));
    }
    
    public final Material getTemplateIcon() {
        Material material = Material.matchMaterial(this.pl.psrvCfg.getString("icon-material"));
        if (material == null) {
            material = Material.GRASS;
        }
        return material;
    }
    
    public final String getTemplateDefaultExpiry() {
        return this.pl.psrvCfg.getString("default-expiry-time");
    }
    
    public final void addTime(final int n, final String s) {
        this.pl.sender.changeExpireTime(true, n, s);
    }
    
    public final void removeTime(final int n, final String s) {
        this.pl.sender.changeExpireTime(false, n, s);
    }
    
    public final long getMillisLeft() {
        return this.pl.msLeft;
    }
    
    public final String getTimeLeft() {
        return this.pl.timeLeft;
    }
    
    public final String getExpireDate() {
        return this.pl.expireDate;
    }
    
    public final void openSettingsGUI(final Player player) {
        this.pl.gui.getGUI("settings").open(player, null);
    }
    
    public final void openGamemodeGUI(final Player player) {
        this.pl.gui.getGUI("gamemode").open(player, null);
    }
    
    public final void openDifficultyGUI(final Player player) {
        this.pl.gui.getGUI("difficulty").open(player, null);
    }
    
    public final void openWhitelistGUI(final Player player) {
        this.pl.gui.getGUI("whitelist").open(player, null);
    }
    
    public final void openPlayerManagerGUI(final Player player, int n) {
        if (n < 1) {
            n = 1;
        }
        this.pl.gui.getGUI("player-manager").open(player, null, n);
    }
    
    public final void openPlayerGUI(final Player player, final Player player2) {
        this.pl.gui.getGUI("player").open(player, null, player2);
    }
    
    public final void openMobGUI(final Player player) {
        this.pl.gui.getGUI("mob-settings").open(player, null);
    }
    
    public final void openWorldGUI(final Player player) {
        this.pl.gui.getGUI("world-settings").open(player, null);
    }
    
    public final HashMap<String, CustomGUI> getGUIMap() {
        return this.pl.gui.customGUIs;
    }
    
    public final CustomGUI getCustomGUI(final String s) {
        if (this.pl.gui.customGUIs.containsKey(s)) {
            return this.pl.gui.customGUIs.get(s);
        }
        return null;
    }
    
    public final void putCustomGUI(final String s, final CustomGUI customGUI) {
        this.pl.gui.customGUIs.put(s, customGUI);
    }
    
    public final void removeCustomGUI(final String s) {
        if (this.pl.gui.customGUIs.containsKey(s)) {
            this.pl.gui.customGUIs.remove(s);
        }
    }
    
    public final CustomGUI newCustomGUI(final String s) {
        final CustomGUI customGUI = new CustomGUI(this.pl);
        this.pl.gui.customGUIs.put(s, customGUI);
        return customGUI;
    }
    
    public final Inventory openCustomGUI(final Player player, String replaceAll, final int n, final Inventory inventory) {
        replaceAll = replaceAll.replaceAll("(&|§)[0-9aA-fFkK-oORr]", "");
        if (!this.customGuis.contains(replaceAll)) {
            this.customGuis.add(replaceAll);
        }
        return new CustomGUI(this.pl).reopenGUI(player, inventory, n, replaceAll);
    }
    
    public final ItemStack customItemStack(final int n, final Material material, final short n2, final String s, final String s2) {
        return this.pl.gui.item(n, material, n2, s, s2);
    }
    
    public final ItemStack customItemStack(final int n, final Material material, final short n2, final String s, final List<String> list) {
        final StringBuilder sb = new StringBuilder();
        final Iterator<String> iterator = list.iterator();
        while (iterator.hasNext()) {
            sb.append(iterator.next());
            sb.append("||");
        }
        return this.pl.gui.item(n, material, n2, s, sb.toString());
    }
    
    public final ItemStack setSelected(final ItemStack itemStack) {
        itemStack.addUnsafeEnchantment((Enchantment)this.pl.gui.SELECTED, 1);
        return itemStack;
    }
    
    public final String getServerPropSetting(final String s) {
        return this.pl.settingsManager.getSetting(s);
    }
    
    public final void setServerPropSetting(final String s, final String s2) {
        this.pl.settingsManager.changeSetting(s, s2);
    }
    
    public final void setServerGamemode(final int gamemode) {
        this.pl.settingsManager.setGamemode(gamemode);
    }
    
    public final void setServerDifficulty(final int difficulty) {
        this.pl.settingsManager.setDifficulty(difficulty);
    }
    
    public final void setServerPvP(final boolean pvP) {
        this.pl.settingsManager.setPvP(pvP);
    }
    
    public final File[] listFiles(final File file) {
        if (file.isDirectory()) {
            return file.listFiles();
        }
        return null;
    }
    
    public final void copyFileSoft(final File file, final File file2) {
        this.pl.utils.doSoftCopy(file, file2);
    }
    
    public final void copyFileHard(final File file, final File file2) {
        this.pl.utils.copyFile(file, file2);
    }
    
    public final void deleteFile(final File file) {
        this.pl.utils.doDelete(file);
    }
    
    public final void startServerName(final String s) {
        final ByteArrayDataOutput dataOutput = ByteStreams.newDataOutput();
        dataOutput.writeUTF("APIcall");
        dataOutput.writeUTF("startServerName");
        dataOutput.writeUTF(s);
        this.pl.sender.apiCall(dataOutput);
    }
    
    public final void startServerUUID(final UUID uuid) {
        final ByteArrayDataOutput dataOutput = ByteStreams.newDataOutput();
        dataOutput.writeUTF("APIcall");
        dataOutput.writeUTF("startServerUUID");
        dataOutput.writeUTF(uuid.toString());
        this.pl.sender.apiCall(dataOutput);
    }
    
    public final void startServerPlayer(final String s) {
        final ByteArrayDataOutput dataOutput = ByteStreams.newDataOutput();
        dataOutput.writeUTF("APIcall");
        dataOutput.writeUTF("startServerPlayer");
        dataOutput.writeUTF(s);
        this.pl.sender.apiCall(dataOutput);
    }
    
    public final void stopServerName(final String s) {
        final ByteArrayDataOutput dataOutput = ByteStreams.newDataOutput();
        dataOutput.writeUTF("APIcall");
        dataOutput.writeUTF("stopServerName");
        dataOutput.writeUTF(s);
        this.pl.sender.apiCall(dataOutput);
    }
    
    public final void stopServerUUID(final UUID uuid) {
        final ByteArrayDataOutput dataOutput = ByteStreams.newDataOutput();
        dataOutput.writeUTF("APIcall");
        dataOutput.writeUTF("stopServerUUID");
        dataOutput.writeUTF(uuid.toString());
        this.pl.sender.apiCall(dataOutput);
    }
    
    public final void stopServerPlayer(final String s) {
        final ByteArrayDataOutput dataOutput = ByteStreams.newDataOutput();
        dataOutput.writeUTF("APIcall");
        dataOutput.writeUTF("stopServerPlayer");
        dataOutput.writeUTF(s);
        this.pl.sender.apiCall(dataOutput);
    }
    
    public final void stopAllServers() {
        final ByteArrayDataOutput dataOutput = ByteStreams.newDataOutput();
        dataOutput.writeUTF("APIcall");
        dataOutput.writeUTF("stopAllServers");
        this.pl.sender.apiCall(dataOutput);
    }
    
    public final void addBungeeServer(final String s, final String s2, final Integer n, final String s3, final int n2) {
        final ByteArrayDataOutput dataOutput = ByteStreams.newDataOutput();
        dataOutput.writeUTF("APIcall");
        dataOutput.writeUTF("addBungeeServer");
        dataOutput.writeUTF(s);
        dataOutput.writeUTF(s2);
        dataOutput.writeUTF(String.valueOf(n));
        dataOutput.writeUTF(s3);
        dataOutput.writeUTF(String.valueOf(n2));
        this.pl.sender.apiCall(dataOutput);
    }
    
    public final void removeBungeeServer(final String s) {
        final ByteArrayDataOutput dataOutput = ByteStreams.newDataOutput();
        dataOutput.writeUTF("APIcall");
        dataOutput.writeUTF("removeBungeeServer");
        dataOutput.writeUTF(s);
        this.pl.sender.apiCall(dataOutput);
    }
    
    public final void createServer(final UUID uuid, final String s) {
        final ByteArrayDataOutput dataOutput = ByteStreams.newDataOutput();
        dataOutput.writeUTF("APIcall");
        dataOutput.writeUTF("createServer");
        dataOutput.writeUTF(uuid.toString());
        dataOutput.writeUTF(s);
        this.pl.sender.apiCall(dataOutput);
    }
    
    public final void deleteServer(final UUID uuid) {
        final ByteArrayDataOutput dataOutput = ByteStreams.newDataOutput();
        dataOutput.writeUTF("APIcall");
        dataOutput.writeUTF("deleteServer");
        dataOutput.writeUTF(uuid.toString());
        this.pl.sender.apiCall(dataOutput);
    }
    
    public final PlayerServers getInstance() {
        return this.pl;
    }
}
