package net.cakemine.playerservers.bungee.sync;

import net.cakemine.playerservers.bungee.*;
import net.md_5.bungee.api.plugin.*;
import net.md_5.bungee.api.connection.*;
import com.google.common.io.*;
import net.md_5.bungee.api.config.*;
import java.util.*;
import net.md_5.bungee.config.*;
import java.io.*;

public class PluginSender
{
    PlayerServers pl;
    public List<Server> syncedServers;
    public String guisSerialized;
    
    public PluginSender(final PlayerServers pl) {
        this.syncedServers = new ArrayList<Server>();
        this.pl = pl;
    }
    
    public void sendPluginMsg(final Server server, final ByteArrayDataOutput byteArrayDataOutput) {
        this.pl.proxy.getScheduler().runAsync((Plugin)this.pl, (Runnable)new Runnable() {
            @Override
            public void run() {
                server.sendData("PlayerServers", byteArrayDataOutput.toByteArray());
            }
        });
    }
    
    public void doSync(final Server server) {
        if (server.getInfo().getPlayers().size() > 0) {
            final ProxiedPlayer proxiedPlayer = server.getInfo().getPlayers().iterator().next();
            if (proxiedPlayer == null) {
                this.pl.utils.debug("Player was null when attempting doSync!");
                return;
            }
            final String string = proxiedPlayer.getUniqueId().toString();
            this.sendStructuredMessage("reSync", string);
            final String[] array2;
            final String[] array = array2 = new String[] { "debug", "version", "messages", "prefix", "fallback", "useExpire", "expiredate", "daysleft", "blockedcmds", "alwaysops", "timeleft", "expirecheck", "templates", "psCustomCmd", "guis" };
            for (final String s : array2) {
                if (this.pl.proxy.getPlayer(UUID.fromString(string)) == null) {
                    this.pl.utils.debug("Player returned null when sending server resync messages, aborting.");
                    return;
                }
                this.sendStructuredMessage(s, string);
            }
            this.confirmSync(server, array.length);
        }
    }
    
    public void confirmSync(final Server server, final int n) {
        final ByteArrayDataOutput dataOutput = ByteStreams.newDataOutput();
        dataOutput.writeUTF("finishSync");
        dataOutput.writeUTF(String.valueOf(n));
        this.sendPluginMsg(server, dataOutput);
    }
    
    public void reSync(final Server server) {
        if (server == null) {
            this.pl.utils.debug("Server was null when attempting a resync!");
            return;
        }
        if (this.syncedServers.size() > 0 && this.syncedServers.contains(server)) {
            this.syncedServers.remove(server);
        }
        if (server.getInfo() == null) {
            this.pl.utils.debug("Server info was null when attempting a resync!");
            return;
        }
        if (server.getInfo().getPlayers() == null) {
            this.pl.utils.debug("Server player collection was null when attempting a resync!");
            return;
        }
        if (server.getInfo().getPlayers().size() > 0) {
            this.doSync(server);
        }
    }
    
    public void reSyncAll() {
        this.syncedServers.clear();
        for (final ServerInfo serverInfo : this.pl.proxy.getServers().values()) {
            if (serverInfo.getPlayers().size() > 0) {
                this.reSync(serverInfo.getPlayers().iterator().next().getServer());
            }
        }
    }
    
    public void controlGUI(final ProxiedPlayer proxiedPlayer) {
        final ByteArrayDataOutput dataOutput = ByteStreams.newDataOutput();
        final Server server = proxiedPlayer.getServer();
        dataOutput.writeUTF("controlGUI");
        final StringBuilder sb = new StringBuilder();
        final String string = proxiedPlayer.getUniqueId().toString();
        sb.append(string).append("———");
        sb.append("has-server").append("###").append(String.valueOf(this.pl.serverManager.hasServer(string))).append("%%%");
        sb.append("use-expire").append("###").append(this.pl.utils.hasPerm(string, "playerservers.bypassexpire") ? "false" : String.valueOf(this.pl.useExpiry)).append("%%%");
        sb.append("time-left").append("###").append(String.valueOf(this.pl.expiryTracker.timeLeft(string))).append("%%%");
        sb.append("files-exist").append("###").append(String.valueOf(this.pl.serverManager.serverFilesExist(string))).append("%%%");
        for (final String s : new String[] { "create", "delete" }) {
            sb.append(s).append("-perm").append("###").append(String.valueOf(this.pl.utils.hasPerm(string, "playerservers.player") || this.pl.utils.hasPerm(string, "playerservers.ps." + s))).append("%%%");
        }
        if (this.pl.serverManager.hasServer(string)) {
            sb.append("is-online").append("###").append(String.valueOf(!this.pl.utils.isPortOpen(this.pl.utils.getSrvIp(string), this.pl.utils.getSrvPort(string)))).append("%%%");
            for (final Map.Entry<String, String> entry : this.pl.serverManager.serverMap.get(string).entrySet()) {
                sb.append(entry.getKey()).append("###").append(String.valueOf((entry.getValue() != null && !entry.getValue().isEmpty() && !entry.getValue().equals("")) ? entry.getValue() : "null")).append("%%%");
            }
        }
        else {
            sb.append("is-online###false%%%");
            sb.append("expire-date###1989-04-20 16:20%%%");
            sb.append("player-name###").append(proxiedPlayer.getName()).append("%%%");
            sb.append("server-name###none%%%");
            sb.append("memory###").append("0M").append("/").append("0M").append("%%%");
            sb.append("server-ip###127.0.0.1%%%");
            sb.append("motd###none%%%");
            sb.append("max-players###0%%%");
            sb.append("white-list###false%%%");
        }
        sb.delete(sb.length() - 3, sb.length());
        this.pl.utils.debug("Opening controlGUI with info: " + (Object)sb);
        dataOutput.writeUTF(sb.toString());
        this.sendPluginMsg(server, dataOutput);
    }
    
    public void worldSelector(final ProxiedPlayer proxiedPlayer) {
        final ByteArrayDataOutput dataOutput = ByteStreams.newDataOutput();
        final Server server = proxiedPlayer.getServer();
        dataOutput.writeUTF("worldselect");
        dataOutput.writeUTF(proxiedPlayer.getUniqueId().toString());
        this.sendPluginMsg(server, dataOutput);
    }
    
    public void serverSelector(final ProxiedPlayer proxiedPlayer) {
        final ByteArrayDataOutput dataOutput = ByteStreams.newDataOutput();
        final Server server = proxiedPlayer.getServer();
        dataOutput.writeUTF("serverselect");
        final StringBuilder sb = new StringBuilder();
        sb.append(proxiedPlayer.getUniqueId().toString()).append("———");
        for (final String s : this.pl.serverManager.playerServers) {
            final String ownerId = this.pl.serverManager.getOwnerId(s);
            sb.append(ownerId).append(":::");
            sb.append("server-name").append("###").append(String.valueOf(s)).append("%%%");
            sb.append("owner-name").append("###").append(String.valueOf(this.pl.utils.getName(ownerId))).append("%%%");
            sb.append("template-name").append("###").append(String.valueOf(this.pl.serverManager.getServerTemplateName(s))).append("%%%");
            sb.append("motd").append("###").append(String.valueOf(this.pl.serverManager.getServerInfo(ownerId, "motd"))).append("%%%");
            sb.append("current-players").append("###").append(String.valueOf(this.pl.proxy.getServerInfo(s).getPlayers().size())).append("%%%");
            sb.append("max-players").append("###").append(String.valueOf(this.pl.serverManager.getServerInfo(ownerId, "max-players"))).append("%%%");
            sb.append("max-memory").append("###").append(String.valueOf(this.pl.serverManager.getServerInfo(ownerId, "memory")).split("\\/")[0]).append("%%%");
            sb.append("expire-date").append("###").append(String.valueOf(this.pl.serverManager.getServerInfo(ownerId, "expire-date"))).append("%%%");
            sb.append("white-list").append("###").append(String.valueOf(this.pl.serverManager.getServerInfo(ownerId, "white-list"))).append("%%%");
            sb.append("time-left").append("###").append(String.valueOf(this.pl.expiryTracker.timeLeft(ownerId)));
            sb.append("@@@");
        }
        sb.delete(sb.length() - 3, sb.length());
        dataOutput.writeUTF(sb.toString());
        this.sendPluginMsg(server, dataOutput);
    }
    
    public void sendStructuredMessage(final String s, final String s2) {
        final ByteArrayDataOutput dataOutput = ByteStreams.newDataOutput();
        if (s2 == null) {
            this.pl.utils.debug("Something went wrong sending a structured plugin message: UUID input was null.");
            return;
        }
        final ProxiedPlayer player = this.pl.proxy.getPlayer(UUID.fromString(s2));
        if (player == null) {
            this.pl.utils.debug("Something went wrong sending a structured plugin message: player was null.");
            return;
        }
        final Server server = player.getServer();
        if (server == null) {
            this.pl.utils.debug("Something went wrong sending a structured plugin message: server was null.");
            return;
        }
        int n = 0;
        switch (s) {
            case "useExpire": {
                dataOutput.writeUTF("useExpire");
                if (this.pl.utils.hasPerm(this.pl.serverManager.getOwnerId(server.getInfo().getName()), "playerservers.bypassexpire")) {
                    dataOutput.writeUTF("false");
                    break;
                }
                dataOutput.writeUTF(String.valueOf(this.pl.useExpiry));
                break;
            }
            case "messages": {
                dataOutput.writeUTF("messages");
                final StringBuilder sb = new StringBuilder();
                for (final Map.Entry<String, String> entry : this.pl.msgMap.entrySet()) {
                    sb.append(entry.getKey().toString()).append(":");
                    sb.append(entry.getValue().toString()).append("––");
                    ++n;
                }
                if (sb.length() > 2) {
                    sb.delete(sb.length() - 2, sb.length());
                }
                this.pl.utils.debug("msgString count = " + n);
                dataOutput.writeUTF(sb.toString());
                break;
            }
            case "templates": {
                dataOutput.writeUTF("templates");
                final StringBuilder sb2 = new StringBuilder();
                final Iterator<Map.Entry<File, Configuration>> iterator2 = this.pl.templateManager.templates.entrySet().iterator();
                while (iterator2.hasNext()) {
                    final Configuration configuration = iterator2.next().getValue();
                    sb2.append("name::").append(configuration.getString("template-name")).append("&&&").append("icon::").append(configuration.getString("icon-material")).append("&&&").append("desc::").append(configuration.getString("description")).append("&&&").append("OP::").append(String.valueOf(configuration.getBoolean("creator-gets-op"))).append("%%%");
                    ++n;
                }
                this.pl.utils.debug("Synced template count = " + n);
                dataOutput.writeUTF(sb2.toString());
                break;
            }
            case "prefix": {
                dataOutput.writeUTF("prefix");
                dataOutput.writeUTF(this.pl.prefix);
                break;
            }
            case "fallback": {
                dataOutput.writeUTF("fallback");
                dataOutput.writeUTF(this.pl.fallbackSrv);
                break;
            }
            case "expiredate": {
                final String expireDate = this.pl.expiryTracker.expireDate(this.pl.utils.getServerUUID(server.getInfo().getName()));
                dataOutput.writeUTF("expiredate");
                dataOutput.writeUTF(expireDate);
                break;
            }
            case "daysleft": {
                final int daysLeft = this.pl.expiryTracker.daysLeft(this.pl.utils.getServerUUID(server.getInfo().getName()));
                dataOutput.writeUTF("daysleft");
                dataOutput.writeUTF(String.valueOf(daysLeft));
                break;
            }
            case "timeleft": {
                dataOutput.writeUTF("timeleft");
                dataOutput.writeUTF(this.pl.expiryTracker.timeLeft(this.pl.utils.getServerUUID(server.getInfo().getName())));
                break;
            }
            case "debug": {
                dataOutput.writeUTF("debug");
                if (this.pl.debug) {
                    dataOutput.writeUTF("1");
                    break;
                }
                dataOutput.writeUTF("0");
                break;
            }
            case "blockedcmds": {
                dataOutput.writeUTF("blockedcmds");
                final StringBuilder sb3 = new StringBuilder();
                final Iterator<String> iterator3 = this.pl.blockedCmds.iterator();
                while (iterator3.hasNext()) {
                    sb3.append(iterator3.next()).append("%%%");
                    ++n;
                }
                sb3.delete(sb3.length() - 3, sb3.length());
                this.pl.utils.debug("Synced Blocked Commands Count = " + n);
                dataOutput.writeUTF(sb3.toString());
                break;
            }
            case "alwaysops": {
                dataOutput.writeUTF("alwaysops");
                final StringBuilder sb4 = new StringBuilder();
                final Iterator<String> iterator4 = this.pl.alwaysOP.iterator();
                while (iterator4.hasNext()) {
                    sb4.append(iterator4.next()).append("%%%");
                    ++n;
                }
                sb4.delete(sb4.length() - 3, sb4.length());
                this.pl.utils.debug("Synced Always-OP List Count = " + n);
                dataOutput.writeUTF(sb4.toString());
                break;
            }
            case "psCustomCmd": {
                dataOutput.writeUTF("psCustomCmd");
                dataOutput.writeUTF(this.pl.psCommand);
                break;
            }
            case "expirecheck": {
                dataOutput.writeUTF("expirecheck");
                if (this.pl.utils.hasPerm(this.pl.serverManager.getOwnerId(server.getInfo().getName()), "playerservers.bypassexpire")) {
                    dataOutput.writeUTF("420");
                    break;
                }
                dataOutput.writeUTF(String.valueOf(this.pl.expiryTracker.msLeft(this.pl.serverManager.getOwnerId(server.getInfo().getName()))));
                break;
            }
            case "version": {
                dataOutput.writeUTF("version");
                dataOutput.writeUTF(this.pl.proxy.getPluginManager().getPlugin("PlayerServers").getDescription().getVersion());
                break;
            }
            case "guis": {
                dataOutput.writeUTF("guis");
                dataOutput.writeUTF(this.guisSerialized);
                break;
            }
            default: {
                return;
            }
        }
        this.pl.sender.sendPluginMsg(server, dataOutput);
    }
}
