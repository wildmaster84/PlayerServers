package net.cakemine.playerservers.bungee.events;

import net.md_5.bungee.api.plugin.*;
import net.cakemine.playerservers.bungee.*;
import net.md_5.bungee.api.config.*;
import java.util.*;

public class ServerAddEvent extends Event implements Cancellable
{
    PlayerServers pl;
    private boolean cancelled;
    private final ServerInfo serverInfo;
    private final UUID uuid;
    private final int memx;
    private final int mems;
    private final int port;
    private final String motd;
    
    public ServerAddEvent(final PlayerServers pl, final ServerInfo serverInfo, final UUID uuid, final int memx, final int mems) {
        this.cancelled = false;
        this.pl = pl;
        this.serverInfo = serverInfo;
        this.uuid = uuid;
        this.memx = memx;
        this.mems = mems;
        this.port = serverInfo.getAddress().getPort();
        this.motd = serverInfo.getMotd();
    }
    
    public ServerInfo getServerInfo() {
        return this.serverInfo;
    }
    
    public String getServerName() {
        return this.serverInfo.getName();
    }
    
    public void setServerName(final String s) {
        this.pl.serverManager.setServerInfo(this.uuid.toString(), "server-name", s);
    }
    
    public UUID getOwnerId() {
        return this.uuid;
    }
    
    public String getOwnerName() {
        return this.pl.utils.getName(this.uuid.toString());
    }
    
    public int getXmx() {
        return this.memx;
    }
    
    public void setXmx(final int n) {
        this.pl.serverManager.setServerInfo(this.uuid.toString(), "memory", n + "M/" + this.pl.serverManager.serverMap.get(this.uuid.toString()).get("memory").split("\\/")[1]);
    }
    
    public int getXms() {
        return this.mems;
    }
    
    public void setXms(final int n) {
        this.pl.serverManager.setServerInfo(this.uuid.toString(), "memory", this.pl.serverManager.serverMap.get(this.uuid.toString()).get("memory").split("\\/")[0] + "/" + n + "M");
    }
    
    public int getPort() {
        return this.port;
    }
    
    public String getMotd() {
        return this.motd;
    }
    
    public void setMotd(final String s) {
        this.pl.settingsManager.changeSetting(this.uuid.toString(), "motd", s);
    }
    
    public boolean isCancelled() {
        return this.cancelled;
    }
    
    public void setCancelled(final boolean cancelled) {
        this.cancelled = cancelled;
    }
}
