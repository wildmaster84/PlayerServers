package net.cakemine.playerservers.bungee;

import net.md_5.bungee.api.connection.*;
import net.cakemine.playerservers.bungee.events.*;
import net.md_5.bungee.api.plugin.*;
import net.md_5.bungee.api.*;
import java.io.*;
import net.md_5.bungee.config.*;
import java.util.*;

public final class PlayerServersAPI
{
    PlayerServers pl;
    
    PlayerServersAPI(final PlayerServers pl) {
        this.pl = pl;
    }
    
    public final boolean getDebugMode() {
        return this.pl.debug;
    }
    
    public final void debugLog(final String s) {
        this.pl.utils.debug(s);
    }
    
    public final String getPluginPrefix() {
        return this.pl.prefix;
    }
    
    public final void setPluginPrefix(final String prefix) {
        this.pl.prefix = prefix;
    }
    
    public final void reSync(final Server server) {
        this.pl.sender.reSync(server);
    }
    
    public final void reSyncAll() {
        this.pl.sender.reSyncAll();
    }
    
    public final LinkedHashMap<String, HashMap<String, String>> getServerMap() {
        return this.pl.serverManager.serverMap;
    }
    
    public final String getServerMapSetting(final String s, final String s2) {
        return this.pl.serverManager.serverMap.get(s).get(s2);
    }
    
    public final void setServerMapSetting(final String s, final String s2, final String s3) {
        this.pl.serverManager.setServerInfo(s, s2, s3);
    }
    
    public final void clearServerMapSetting(final String s, final String s2) {
        this.pl.serverManager.serverMap.get(s).remove(s2);
        this.pl.proxy.getPluginManager().callEvent((Event)new ServerModifyEvent(this.pl, s));
    }
    
    public final void saveServerMap() {
        this.pl.serverManager.saveServerMap();
    }
    
    public final List<String> getOnlinePlayerServers() {
        return this.pl.serverManager.playerServers;
    }
    
    public final boolean getServerOnline(final String s) {
        final String serverUUID = this.pl.utils.getServerUUID(s);
        return !this.pl.utils.isPortOpen(this.pl.utils.getSrvIp(serverUUID), this.pl.utils.getSrvPort(serverUUID));
    }
    
    public final boolean serverFilesExist(final String s) {
        return this.pl.serverManager.serverFilesExist(this.pl.serverManager.getOwnerId(s));
    }
    
    public final boolean serverFilesExistUUID(final String s) {
        return this.pl.serverManager.serverFilesExist(s);
    }
    
    public final UUID getServerOwnerId(final String s) {
        return UUID.fromString(this.pl.utils.getServerUUID(s));
    }
    
    public final String getServerOwnerName(final String s) {
        return this.pl.utils.getName(this.pl.serverManager.getOwnerId(s));
    }
    
    public final String getServerTemplateName(final String s) {
        return this.pl.serverManager.getServerTemplateName(s);
    }
    
    public final int getServerXmx(final String s) {
        if (this.pl.serverManager.getOwnerId(s) == null) {
            return 0;
        }
        return this.pl.utils.memStringToInt(this.pl.serverManager.serverMap.get(this.pl.serverManager.getOwnerId(s)).get("memory").split("\\/")[0]);
    }
    
    public final int getServerXms(final String s) {
        if (this.pl.serverManager.getOwnerId(s) == null) {
            return 0;
        }
        return this.pl.utils.memStringToInt(this.pl.serverManager.serverMap.get(this.pl.serverManager.getOwnerId(s)).get("memory").split("\\/")[1]);
    }
    
    public final String getPlayerServerName(final UUID uuid) {
        return this.pl.utils.getSrvName(uuid.toString());
    }
    
    public final void setPlayerServerName(final UUID uuid, final String s) {
        this.pl.serverManager.setServerInfo(uuid.toString(), "server-name", s);
    }
    
    public final int getPlayerServerPort(final UUID uuid) {
        return this.pl.utils.getSrvPort(uuid.toString());
    }
    
    public final String getPropertiesSetting(final UUID uuid, final String s) {
        return this.pl.settingsManager.getSetting(uuid.toString(), s);
    }
    
    public final void setPropertiesSetting(final UUID uuid, final String s, final String s2) {
        this.pl.settingsManager.changeSetting(uuid.toString(), s, s2);
    }
    
    public final void startServerName(final String s) {
        this.pl.serverManager.startupSrv(this.pl.utils.getServerUUID(s), null);
    }
    
    public final void startServerUUID(final UUID uuid) {
        this.pl.serverManager.startupSrv(uuid.toString(), null);
    }
    
    public final void startServerPlayer(final String s) {
        this.pl.serverManager.startupSrv(this.pl.utils.getUUID(s), null);
    }
    
    public final void stopServerName(final String s) {
        this.pl.serverManager.stopSrv(this.pl.utils.getServerUUID(s));
    }
    
    public final void stopServerUUID(final UUID uuid) {
        this.pl.serverManager.stopSrv(uuid.toString());
    }
    
    public final void stopServerPlayer(final String s) {
        this.pl.serverManager.stopSrv(this.pl.utils.getUUID(s));
    }
    
    public final void stopAllServers() {
        this.pl.serverManager.stopAll(null);
    }
    
    public final void addBungeeServer(final String s, final String s2, final Integer n, final String s3, final int n2) {
        this.pl.serverManager.addBungee(s, s2, n, s3, n2);
    }
    
    public final void removeBungeeServer(final String s) {
        this.pl.serverManager.removeBungee(s);
    }
    
    public final void createServer(final UUID uuid, final String s) {
        this.pl.serverManager.createServer(null, this.pl.utils.getName(uuid.toString()), uuid.toString(), this.pl.templateManager.getTemplateFile(s));
    }
    
    public final void deleteServer(final UUID uuid) {
        this.pl.serverManager.deleteServer(null, uuid.toString());
    }
    
    public final List<String> getAvailableTemplateNames() {
        final ArrayList<String> list = new ArrayList<String>();
        final Iterator<File> iterator = this.pl.templateManager.templates.keySet().iterator();
        while (iterator.hasNext()) {
            list.add(this.pl.templateManager.getTemplateSetting(iterator.next(), "template-name"));
        }
        return list;
    }
    
    public final String getTemplateDescription(final String s) {
        if (this.pl.templateManager.getTemplateFile(s) == null) {
            return null;
        }
        return this.pl.templateManager.getTemplateSetting(this.pl.templateManager.getTemplateFile(s), "template-name");
    }
    
    public final List<String> getTemplateDescriptionList(final String s) {
        if (this.pl.templateManager.getTemplateFile(s) == null) {
            return null;
        }
        return Arrays.asList(this.pl.templateManager.getTemplateSetting(this.pl.templateManager.getTemplateFile(s), "template-name").split("||"));
    }
    
    public final boolean isTemplateCreatorOp(final String s) {
        return this.pl.templateManager.getTemplateFile(s) != null && this.pl.templateManager.getTemplateSetting(this.pl.templateManager.getTemplateFile(s), "creator-gets-op").equalsIgnoreCase("true");
    }
    
    public final boolean isTemplateExpireShutdown(final String s) {
        return this.pl.templateManager.getTemplateFile(s) != null && this.pl.templateManager.getTemplateSetting(this.pl.templateManager.getTemplateFile(s), "shutdown-on-expire").equalsIgnoreCase("true");
    }
    
    public final String getTemplateExpiryHuman(final String s) {
        if (this.pl.templateManager.getTemplateFile(s) == null) {
            return null;
        }
        return this.pl.templateManager.getTemplateSetting(this.pl.templateManager.getTemplateFile(s), "default-expiry-time");
    }
    
    public final boolean setTemplateName(final String s, final String s2) {
        if (this.pl.templateManager.getTemplateFile(s) == null) {
            return false;
        }
        this.pl.templateManager.templates.get(this.pl.templateManager.getTemplateFile(s)).set("template-name", (Object)s2);
        return true;
    }
    
    public final boolean setTemplateDescrption(final String s, final String s2) {
        if (this.pl.templateManager.getTemplateFile(s) == null) {
            return false;
        }
        this.pl.templateManager.templates.get(this.pl.templateManager.getTemplateFile(s)).set("description", (Object)s2);
        return true;
    }
    
    public final boolean setTemplateMaterial(final String s, final String s2) {
        if (this.pl.templateManager.getTemplateFile(s) == null) {
            return false;
        }
        this.pl.templateManager.templates.get(this.pl.templateManager.getTemplateFile(s)).set("icon-material", (Object)s2);
        return true;
    }
    
    public final boolean setTemplateCreatorOP(final String s, final boolean b) {
        if (this.pl.templateManager.getTemplateFile(s) == null) {
            return false;
        }
        this.pl.templateManager.templates.get(this.pl.templateManager.getTemplateFile(s)).set("creator-gets-op", (Object)b);
        return true;
    }
    
    public final boolean setTemplateExpireShutdown(final String s, final boolean b) {
        if (this.pl.templateManager.getTemplateFile(s) == null) {
            return false;
        }
        this.pl.templateManager.templates.get(this.pl.templateManager.getTemplateFile(s)).set("shutdown-on-expire", (Object)b);
        return true;
    }
    
    public final boolean setTemplateExpiryTime(final String s, final String s2) {
        if (this.pl.templateManager.getTemplateFile(s) == null) {
            return false;
        }
        this.pl.templateManager.templates.get(this.pl.templateManager.getTemplateFile(s)).set("default-expire-time", (Object)s2);
        return true;
    }
    
    public final void addTime(final UUID uuid, final int n, final String s) {
        this.pl.expiryTracker.addTime(uuid.toString(), n, s);
    }
    
    public final void removeTime(final UUID uuid, final int n, final String s) {
        this.pl.expiryTracker.removeTime(uuid.toString(), n, s);
    }
    
    public final long getMillisLeft(final UUID uuid) {
        return this.pl.expiryTracker.msLeft(uuid.toString());
    }
    
    public final String getTimeLeft(final UUID uuid) {
        return this.pl.expiryTracker.timeLeft(uuid.toString());
    }
    
    public final String getExpireDate(final UUID uuid) {
        return this.pl.expiryTracker.getDate(uuid.toString());
    }
    
    public final String getPlayerName(final UUID uuid) {
        return this.pl.utils.getName(uuid.toString());
    }
    
    public final UUID getPlayerUUID(final String s) {
        if (this.pl.utils.getUUID(s) == null) {
            return null;
        }
        return UUID.fromString(this.pl.utils.getUUID(s));
    }
    
    public final void putPlayerMapEntry(final String s, final UUID uuid) {
        this.pl.putPlayer(s, uuid.toString());
    }
    
    public final boolean removePlayerMapEntry(final String s) {
        if (this.pl.playerMap.containsKey(s)) {
            this.pl.playerMap.remove(s);
            return true;
        }
        return false;
    }
    
    public final boolean removedPlayerMapEntryUUID(final UUID uuid) {
        boolean b = false;
        if (this.pl.playerMap.containsValue(uuid.toString())) {
            final Iterator<Map.Entry<String, String>> iterator = this.pl.playerMap.entrySet().iterator();
            while (iterator.hasNext()) {
                if (iterator.next().getValue().equals(uuid.toString())) {
                    iterator.remove();
                    b = true;
                }
            }
        }
        return b;
    }
    
    public final File[] listFiles(final File file) {
        if (file.isDirectory()) {
            return file.listFiles();
        }
        return null;
    }
    
    public final void copyFileSoft(final File file, final File file2) {
        this.pl.serverManager.doCopy(file, file2);
    }
    
    public final void copyFileHard(final File file, final File file2) {
        this.pl.utils.copyFile(file, file2);
    }
    
    public final void deleteFile(final File file) {
        this.pl.serverManager.doDelete(file);
    }
}
