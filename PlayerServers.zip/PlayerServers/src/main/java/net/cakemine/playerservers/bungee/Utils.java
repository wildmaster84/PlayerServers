package net.cakemine.playerservers.bungee;

import java.util.logging.*;
import net.md_5.bungee.api.plugin.*;
import net.md_5.bungee.api.chat.*;
import java.util.concurrent.*;
import com.google.common.base.*;
import java.util.*;
import com.google.gson.*;
import java.io.*;
import java.net.*;
import java.util.regex.*;
import net.md_5.bungee.api.*;
import net.md_5.bungee.api.connection.*;

public class Utils
{
    PlayerServers pl;
    
    public Utils(final PlayerServers pl) {
        this.pl = pl;
    }
    
    public void sendMsg(final ProxiedPlayer proxiedPlayer, final String s) {
        if (s == null) {
            this.log(Level.WARNING, "Message missing somehow! Update your messages.yml, MOVE it (to keep a backup of your changes) and let it regenerate.");
            return;
        }
        if (s.isEmpty()) {
            return;
        }
        if (s.contains("||")) {
            final String[] split = s.split("\\|\\|");
            for (int length = split.length, i = 0; i < length; ++i) {
                proxiedPlayer.sendMessage(TextComponent.fromLegacyText(this.pl.utils.color(this.pl.prefix + split[i])));
            }
        }
        else {
            proxiedPlayer.sendMessage(TextComponent.fromLegacyText(this.color(this.pl.prefix + s)));
        }
    }
    
    public void sendMsg(final CommandSender commandSender, final String s) {
        if (s == null || s.isEmpty() || s.matches("^" + this.pl.prefix + "(\\s)?$")) {
            this.log(Level.WARNING, "Message missing somehow! Update your messages.yml, MOVE it (to keep a backup of your changes) and let it regenerate.");
            return;
        }
        if (s.isEmpty()) {
            return;
        }
        if (s.contains("||")) {
            final String[] split = s.split("\\|\\|");
            for (int length = split.length, i = 0; i < length; ++i) {
                commandSender.sendMessage(TextComponent.fromLegacyText(this.color(this.pl.prefix + split[i])));
            }
        }
        else {
            commandSender.sendMessage(TextComponent.fromLegacyText(this.color(this.pl.prefix + s)));
        }
    }
    
    public String color(final String s) {
        return ChatColor.translateAlternateColorCodes('&', s);
    }
    
    public String stripColor(final String s) {
        return ChatColor.stripColor(this.color(s));
    }
    
    public void movePlayer(final ProxiedPlayer proxiedPlayer, final String s, final int n) {
        if (proxiedPlayer == null) {
            this.log(Level.SEVERE, "Player returned null when trying to send them to a server! Did they disconnect?");
            return;
        }
        if (s == null) {
            this.log(Level.SEVERE, "Server returned null when trying to send " + proxiedPlayer.getName() + " to it! Server removed/shutdown/failed to start?");
            return;
        }
        if (n <= 0) {
            if (this.pl.proxy.getServerInfo(s) == null) {
                this.log(Level.SEVERE, "Server info for server '" + s + "' returned null when trying to send " + proxiedPlayer.getName() + " to it! Server removed/shutdown/failed to start?");
                return;
            }
            proxiedPlayer.connect(this.pl.proxy.getServerInfo(s));
        }
        else {
            this.pl.proxy.getScheduler().schedule((Plugin)this.pl, (Runnable)new Runnable() {
                @Override
                public void run() {
                    if (Utils.this.pl.proxy.getServerInfo(s) == null) {
                        Utils.this.log(Level.SEVERE, "Server info for server '" + s + "' returned null when trying to send " + proxiedPlayer.getName() + " to it! Server removed/shutdown/failed to start?");
                        return;
                    }
                    proxiedPlayer.connect(Utils.this.pl.proxy.getServerInfo(s));
                }
            }, (long)n, TimeUnit.SECONDS);
        }
    }
    
    public void helpMessage(final CommandSender commandSender, String replaceAll, final String s) {
        if (commandSender instanceof ProxiedPlayer) {
            if (!this.pl.psCommand.equals("playerserver")) {
                replaceAll = replaceAll.replaceAll("/ps ", "/" + this.pl.psCommand + " ");
            }
            final ProxiedPlayer proxiedPlayer = (ProxiedPlayer)commandSender;
            final TextComponent textComponent = new TextComponent("» ");
            textComponent.setColor(ChatColor.DARK_GRAY);
            final TextComponent textComponent2 = new TextComponent(replaceAll);
            textComponent2.setColor(ChatColor.YELLOW);
            textComponent2.setItalic(true);
            textComponent2.setHoverEvent(new HoverEvent(HoverEvent.Action.SHOW_TEXT, new ComponentBuilder(this.color("&e&o" + s)).create()));
            textComponent.addExtra((BaseComponent)textComponent2);
            proxiedPlayer.sendMessage((BaseComponent)textComponent);
        }
        else {
            commandSender.sendMessage(TextComponent.fromLegacyText(ChatColor.AQUA + ChatColor.stripColor(replaceAll) + ChatColor.GRAY + " » " + ChatColor.YELLOW + ChatColor.stripColor(s)));
        }
    }
    
    public String getSrvName(final String s) {
        if (!this.pl.serverManager.hasServer(s)) {
            this.pl.utils.log(Level.WARNING, "Tried to get server name for " + s + "'s server, but server did not exist in the server map (servers.yml)! Returned \"empty\"");
            return "empty";
        }
        if (this.pl.serverManager.getServerInfo(s, "server-name") != null && !this.pl.serverManager.getServerInfo(s, "server-name").equalsIgnoreCase("null")) {
            return this.pl.serverManager.getServerInfo(s, "server-name");
        }
        if (this.pl.settingsManager.propExists(s) && this.pl.settingsManager.getSetting(s, "server-name") != null && !this.pl.settingsManager.getSetting(s, "server-name").equalsIgnoreCase("null")) {
            return this.pl.settingsManager.getSetting(s, "server-name");
        }
        this.pl.utils.log(Level.SEVERE, s + "'s server name was null! Using their name instead");
        return this.pl.utils.getName(s);
    }
    
    public String getSrvIp(final String s) {
        if (!this.pl.serverManager.hasServer(s)) {
            this.pl.utils.log(Level.WARNING, "Tried to get server IP for " + s + "'s server, but server did not exist in the server map (servers.yml)!");
            return "127.0.0.1";
        }
        if (this.pl.serverManager.serverMap.get(s).containsKey("server-ip")) {
            return this.pl.serverManager.serverMap.get(s).get("server-ip");
        }
        this.pl.serverManager.verifySettings(s);
        final String setting;
        if (s == null || s.equalsIgnoreCase("null") || (setting = this.pl.settingsManager.getSetting(s, "server-ip")) == null) {
            return "127.0.0.1";
        }
        if (this.pl.serverManager.hasServer(s) && (this.pl.serverManager.getServerInfo(s, "server-ip") == null || this.pl.serverManager.getServerInfo(s, "server-ip").equalsIgnoreCase("null") || !this.pl.serverManager.serverMap.get(s).get("server-ip").equalsIgnoreCase(setting))) {
            this.pl.serverManager.setServerInfo(s, "server-ip", setting);
        }
        return setting;
    }
    
    public int getSrvPort(final String s) {
        if (s != null && !s.equalsIgnoreCase("null")) {
            if (!this.pl.serverManager.hasServer(s)) {
                this.pl.utils.log(Level.WARNING, "Tried to get server port for " + s + "'s server, but server did not exist in the server map (servers.yml)!");
                return 0;
            }
            if (String.valueOf(this.pl.serverManager.getServerInfo(s, "port")).matches("(\\d)+")) {
                return Integer.parseInt(this.pl.serverManager.getServerInfo(s, "port"));
            }
            if (this.pl.settingsManager.propExists(s) && this.pl.settingsManager.getSetting(s, "server-port").matches("(\\d)+")) {
                return Integer.parseInt(this.pl.settingsManager.getSetting(s, "server-port"));
            }
        }
        this.pl.utils.log(Level.SEVERE, "Server port was not a number! " + s + " | servers.yml value: " + String.valueOf(this.pl.serverManager.getServerInfo(s, "port")) + " | server.properties value: " + String.valueOf(this.pl.settingsManager.getSetting(s, "server-port")));
        return 0;
    }
    
    public int getNextPort() {
        return this.pl.config.getInt("next-port");
    }
    
    public void iteratePort() {
        this.pl.config.set("next-port", (Object)(this.getNextPort() + 1));
        this.pl.saveConfig(this.pl.config, "config.yml");
    }
    
    public boolean isPortOpen(final String s, final int n) {
        final FutureTask<Boolean> futureTask = new FutureTask<Boolean>(new Callable<Boolean>() {
            @Override
            public Boolean call() {
                boolean b = false;
                Socket socket = null;
                if (s.equals(Utils.this.pl.utils.getProxyIp())) {
                    Utils.this.pl.utils.debug("isPortOpen input address was the same as proxy address! Check server.properties settings of your server templates is set to 127.0.0.1!");
                }
                try {
                    socket = new Socket();
                    socket.connect(new InetSocketAddress(s, n), 2500);
                    b = false;
                }
                catch (Exception ex3) {
                    b = true;
                    if (socket != null) {
                        try {
                            socket.close();
                        }
                        catch (IOException ex) {
                            ex.printStackTrace();
                        }
                    }
                }
                finally {
                    if (socket != null) {
                        try {
                            socket.close();
                        }
                        catch (IOException ex2) {
                            ex2.printStackTrace();
                        }
                    }
                }
                return b;
            }
        });
        this.pl.proxy.getScheduler().runAsync((Plugin)this.pl, (Runnable)futureTask);
        try {
            return futureTask.get(3L, TimeUnit.SECONDS);
        }
        catch (InterruptedException ex) {
            ex.printStackTrace();
        }
        catch (ExecutionException ex2) {
            ex2.printStackTrace();
        }
        catch (TimeoutException ex3) {
            this.pl.utils.debug("Timed out while trying to check if port was open. Assuming it's closed.");
        }
        return false;
    }
    
    public String getServerUUID(final String s) {
        for (final Map.Entry<String, HashMap<String, String>> entry : this.pl.serverManager.serverMap.entrySet()) {
            if (s.equals(entry.getValue().get("server-name"))) {
                return entry.getKey().toString();
            }
        }
        return null;
    }
    
    public boolean hasJoined(final String s) {
        return this.pl.playerMap.containsKey(s);
    }
    
    public String getUUID(final String s) {
        final long currentTimeMillis = System.currentTimeMillis();
        if (this.pl.playerMap.containsKey(s)) {
            this.debug("Finished lookup (direct): " + (System.currentTimeMillis() - currentTimeMillis) + "ms later.");
            return this.pl.playerMap.get(s);
        }
        for (final String s2 : this.pl.playerMap.keySet()) {
            if (s2.equalsIgnoreCase(s)) {
                this.debug("Finished lookup (loop): " + (System.currentTimeMillis() - currentTimeMillis) + "ms later.");
                return this.pl.playerMap.get(s2);
            }
        }
        if (this.pl.proxy.getConfig().isOnlineMode()) {
            this.log(Level.WARNING, s + "'s UUID needed but not stored, fetching it from the web.");
            final String fetchUUID = this.fetchUUID(s);
            if (fetchUUID != null) {
                this.debug("That's so fetch. " + (System.currentTimeMillis() - currentTimeMillis) + "ms later.");
                return fetchUUID;
            }
        }
        this.log(Level.SEVERE, s + "'s UUID not found! getUUID returned null! " + (System.currentTimeMillis() - currentTimeMillis) + "ms later.");
        return null;
    }
    
    public String fetchUUID(final String s) {
        if (this.pl.playerMap.containsKey(s)) {
            return this.pl.playerMap.get(s);
        }
        if (!this.pl.proxy.getConfig().isOnlineMode()) {
            this.pl.utils.debug("Offline mode network, generating UUID from OfflinePlayer name.");
            return UUID.nameUUIDFromBytes(("OfflinePlayer:" + s).getBytes(Charsets.UTF_8)).toString();
        }
        final FutureTask<String> futureTask = new FutureTask<String>(new Callable<String>() {
            @Override
            public String call() {
                try {
                    final URLConnection openConnection = new URL("https://mc-api.net/v3/uuid/" + s).openConnection();
                    openConnection.setConnectTimeout(1000);
                    openConnection.setReadTimeout(1000);
                    openConnection.setRequestProperty("User-Agent", "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/46.0.2490.71 Safari/537.36");
                    final String line = new BufferedReader(new InputStreamReader(openConnection.getInputStream())).readLine();
                    Utils.this.debug("mc-api.net response = " + line);
                    final JsonObject jsonObject = (JsonObject)new Gson().fromJson(line, (Class)JsonObject.class);
                    if (jsonObject.get("error") == null || jsonObject.get("full_uuid") != null) {
                        final String asString = jsonObject.get("full_uuid").getAsString();
                        Utils.this.pl.putPlayer(s, asString);
                        Utils.this.debug("fetchUUID from MC-API.NET returned " + asString);
                        return asString;
                    }
                    Utils.this.log("Unable to fetch " + s + "'s UUID from mc-api.net, error: " + jsonObject.get("error").getAsString());
                    Utils.this.log("Trying next UUID source...");
                }
                catch (SocketTimeoutException ex4) {
                    Utils.this.log(Level.WARNING, "Connection to mc-api.net timed out, trying next provider...");
                }
                catch (FileNotFoundException ex5) {
                    Utils.this.debug("FileNotFoundException, usually means the username is invalid.");
                }
                catch (IOException ex) {
                    Utils.this.log(Level.SEVERE, "unable to fetch " + s + "'s UUID from mc-api.net!");
                    Utils.this.log("Trying next UUID source...");
                    if (Utils.this.pl.debug) {
                        ex.printStackTrace();
                    }
                }
                try {
                    final URLConnection openConnection2 = new URL("http://mcuuid.com/api/" + s).openConnection();
                    openConnection2.setConnectTimeout(2000);
                    openConnection2.setReadTimeout(1500);
                    openConnection2.setRequestProperty("User-Agent", "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/46.0.2490.71 Safari/537.36");
                    final String line2 = new BufferedReader(new InputStreamReader(openConnection2.getInputStream())).readLine();
                    Utils.this.debug("mcuuid.com response = " + line2);
                    final JsonObject jsonObject2 = (JsonObject)new Gson().fromJson(line2, (Class)JsonObject.class);
                    if (jsonObject2.get("uuid") != null) {
                        final String asString2 = jsonObject2.get("uuid_formatted").getAsString();
                        Utils.this.pl.putPlayer(s, asString2);
                        Utils.this.debug("fetchUUID from MCUUID.COM returns " + asString2);
                        return asString2;
                    }
                    Utils.this.log("Unable to fetch " + s + "'s UUID from mcuuid.com, error: " + jsonObject2.get("error").getAsString());
                }
                catch (SocketTimeoutException ex6) {
                    Utils.this.log(Level.WARNING, "Connection to mc-api.net timed out, trying next provider...");
                }
                catch (FileNotFoundException ex7) {
                    Utils.this.debug("FileNotFoundException, usually means the username is invalid or website is down.");
                }
                catch (IOException ex2) {
                    Utils.this.log(Level.SEVERE, "Unable to fetch " + s + "'s UUID from mcuuid.com");
                    if (Utils.this.pl.debug) {
                        ex2.printStackTrace();
                    }
                }
                try {
                    final URLConnection openConnection3 = new URL("https://api.mojang.com/users/profiles/minecraft/" + s).openConnection();
                    openConnection3.setConnectTimeout(1500);
                    openConnection3.setReadTimeout(1500);
                    openConnection3.setRequestProperty("User-Agent", "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/46.0.2490.71 Safari/537.36");
                    final String line3 = new BufferedReader(new InputStreamReader(openConnection3.getInputStream())).readLine();
                    Utils.this.debug("mojang response = " + line3);
                    final JsonObject jsonObject3 = (JsonObject)new Gson().fromJson(line3, (Class)JsonObject.class);
                    if (jsonObject3.get("error") == null) {
                        final String replaceAll = jsonObject3.get("id").getAsString().replaceAll("(\\w{8})(\\w{4})(\\w{4})(\\w{4})(\\w{12})", "$1-$2-$3-$4-$5");
                        Utils.this.pl.putPlayer(s, replaceAll);
                        Utils.this.debug("fetchUUID from Mojang returns " + replaceAll);
                        return replaceAll;
                    }
                    Utils.this.log("Unable to fetch " + s + "'s UUID from Mojang, error: " + jsonObject3.get("error").getAsString());
                }
                catch (SocketTimeoutException ex8) {
                    Utils.this.log(Level.WARNING, "Connection to mc-api.net timed out, trying next provider...");
                }
                catch (FileNotFoundException ex9) {
                    Utils.this.debug("FileNotFoundException, usually means the username is invalid or the website is down.");
                }
                catch (IOException ex3) {
                    Utils.this.log(Level.SEVERE, "Unable to fetch " + s + "'s UUID from Mojang");
                    if (Utils.this.pl.debug) {
                        ex3.printStackTrace();
                    }
                }
                return null;
            }
        });
        this.pl.proxy.getScheduler().runAsync((Plugin)this.pl, (Runnable)futureTask);
        try {
            return futureTask.get(5L, TimeUnit.SECONDS);
        }
        catch (InterruptedException ex) {
            ex.printStackTrace();
        }
        catch (ExecutionException ex2) {
            ex2.printStackTrace();
        }
        catch (TimeoutException ex3) {
            ex3.printStackTrace();
        }
        return null;
    }
    
    public String fetchName(final String s) {
        if (this.pl.playerMap.containsValue(s)) {
            for (final Map.Entry<String, String> entry : this.pl.playerMap.entrySet()) {
                if (entry.getValue().equals(s)) {
                    return entry.getKey();
                }
            }
        }
        if (!this.pl.proxy.getConfig().isOnlineMode()) {
            this.pl.utils.debug("Cannot fetch name on offline-mode networks.");
            return null;
        }
        final FutureTask<String> futureTask = new FutureTask<String>(new Callable<String>() {
            @Override
            public String call() {
                try {
                    final URLConnection openConnection = new URL("https://mc-api.net/v3/name/" + s).openConnection();
                    openConnection.setConnectTimeout(1500);
                    openConnection.setReadTimeout(1500);
                    openConnection.setRequestProperty("User-Agent", "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/46.0.2490.71 Safari/537.36");
                    final String line = new BufferedReader(new InputStreamReader(openConnection.getInputStream())).readLine();
                    Utils.this.debug("mc-api.net response = " + line);
                    final JsonObject jsonObject = (JsonObject)new Gson().fromJson(line, (Class)JsonObject.class);
                    if (jsonObject.get("error") == null || jsonObject.get("full_uuid") != null) {
                        final String asString = jsonObject.get("name").getAsString();
                        Utils.this.pl.putPlayer(asString, s);
                        Utils.this.debug("fetchName returned " + asString);
                        return asString;
                    }
                    Utils.this.log("Unable to fetch " + s + "'s name from mc-api.net, error: " + jsonObject.get("error").getAsString());
                    Utils.this.log("Trying next lookup source...");
                }
                catch (SocketTimeoutException ex3) {
                    Utils.this.log(Level.WARNING, "Connection to mc-api.net timed out, trying next provider...");
                }
                catch (FileNotFoundException ex4) {
                    Utils.this.debug("FileNotFoundException, usually means the UUID is invalid.");
                }
                catch (IOException ex) {
                    Utils.this.log(Level.SEVERE, "unable to fetch " + s + "'s name from mc-api.net!");
                    Utils.this.log("Trying next UUID source...");
                    ex.printStackTrace();
                }
                try {
                    final URLConnection openConnection2 = new URL("http://mcuuid.com/api/" + s).openConnection();
                    openConnection2.setConnectTimeout(2000);
                    openConnection2.setReadTimeout(1500);
                    openConnection2.setRequestProperty("User-Agent", "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/46.0.2490.71 Safari/537.36");
                    final String line2 = new BufferedReader(new InputStreamReader(openConnection2.getInputStream())).readLine();
                    Utils.this.debug("mcuuid.com response = " + line2);
                    final JsonObject jsonObject2 = (JsonObject)new Gson().fromJson(line2, (Class)JsonObject.class);
                    if (jsonObject2.get("name") != null) {
                        final String asString2 = jsonObject2.get("name").getAsString();
                        Utils.this.pl.putPlayer(asString2, s);
                        Utils.this.debug("fetchName returns " + asString2);
                        return asString2;
                    }
                    Utils.this.log("Unable to fetch " + s + "'s name from mcuuid.com, error: " + jsonObject2.get("error").getAsString());
                }
                catch (SocketTimeoutException ex5) {
                    Utils.this.log(Level.WARNING, "Connection to mcuuid.com timed out, end of provider list!");
                }
                catch (FileNotFoundException ex6) {
                    Utils.this.debug("FileNotFoundException, usually means the username is invalid or website is down.");
                }
                catch (IOException ex2) {
                    Utils.this.log(Level.SEVERE, "Unable to fetch " + s + "'s name from mcuuid.com");
                    ex2.printStackTrace();
                }
                return null;
            }
        });
        this.pl.proxy.getScheduler().runAsync((Plugin)this.pl, (Runnable)futureTask);
        try {
            return futureTask.get(5L, TimeUnit.SECONDS);
        }
        catch (InterruptedException ex) {
            ex.printStackTrace();
        }
        catch (ExecutionException ex2) {
            ex2.printStackTrace();
        }
        catch (TimeoutException ex3) {
            ex3.printStackTrace();
        }
        return null;
    }
    
    public String getName(final String s) {
        String fetchName = null;
        if (s == null) {
            this.log(Level.SEVERE, "getName was passed a NULL UUID. Please send the following stack trace to the developer:");
            Thread.dumpStack();
            return null;
        }
        if (this.pl.playerMap.containsValue(s)) {
            for (final Map.Entry<String, String> entry : this.pl.playerMap.entrySet()) {
                if (entry.getKey() == null) {
                    this.pl.utils.log(Level.WARNING, "A playerMap key was null!");
                }
                else if (entry.getValue() == null) {
                    this.pl.utils.log(Level.WARNING, entry.getKey() + "'s playerMap value was null!");
                }
                else {
                    if (!entry.getValue().equals(s)) {
                        continue;
                    }
                    fetchName = entry.getKey();
                }
            }
        }
        if (fetchName == null) {
            fetchName = this.fetchName(s);
        }
        if (fetchName == null) {
            this.log(Level.SEVERE, s + "'s name not found in server map and can't/failed to fetch! getName returned null!");
        }
        return fetchName;
    }
    
    public String getProxyIp() {
        if (this.pl.proxyAddress == null) {
            this.pl.utils.log("Checking external IP address...");
            String line = null;
            BufferedReader bufferedReader = null;
            try {
                bufferedReader = new BufferedReader(new InputStreamReader(new URL("http://checkip.amazonaws.com").openStream()));
                line = bufferedReader.readLine();
            }
            catch (IOException ex) {
                ex.printStackTrace();
                if (bufferedReader != null) {
                    try {
                        bufferedReader.close();
                    }
                    catch (IOException ex2) {
                        ex2.printStackTrace();
                    }
                }
            }
            finally {
                if (bufferedReader != null) {
                    try {
                        bufferedReader.close();
                    }
                    catch (IOException ex3) {
                        ex3.printStackTrace();
                    }
                }
            }
            if (line == null) {
                this.pl.utils.log(Level.WARNING, "Proxy IP returned null!");
            }
            else {
                this.pl.utils.log("Proxy external IP found: " + line);
            }
            return line;
        }
        return this.pl.proxyAddress;
    }
    
    public void log(final Level level, final String s) {
        this.pl.getLogger().log(level, this.color(s));
    }
    
    public void log(final String s) {
        this.pl.getLogger().info(ChatColor.translateAlternateColorCodes('&', s));
    }
    
    public void debug(final String s) {
        if (this.pl.debug) {
            this.pl.getLogger().warning("DEBUG: " + s);
        }
    }
    
    public String doPlaceholders(final String s, String s2) {
        if (s2.contains("%server-owner%")) {
            s2 = s2.replaceAll("%server-owner%", (this.getName(s) != null) ? this.getName(s) : "this player");
        }
        if (s2.contains("%fallback-server%")) {
            s2 = s2.replaceAll("%fallback-server%", this.pl.fallbackSrv);
        }
        if (s2.contains("%days-left%")) {
            s2 = s2.replaceAll("%days-left%", String.valueOf(this.pl.expiryTracker.daysLeft(s)));
        }
        if (s2.contains("%time-left%")) {
            s2 = s2.replaceAll("%time-left%", this.pl.expiryTracker.timeLeft(s));
        }
        if (s2.contains("%expire-date%")) {
            s2 = s2.replaceAll("%expire-date%", this.pl.expiryTracker.expireDate(s));
        }
        if (s2.contains("%max-mem%")) {
            s2 = s2.replaceAll("%max-mem%", String.valueOf(this.pl.serverManager.getServerInfo(s, "memory")).split("\\/")[0]);
        }
        if (s2.contains("%start-mem%")) {
            s2 = s2.replaceAll("%start-mem%", String.valueOf(this.pl.serverManager.getServerInfo(s, "memory")).split("\\/")[1]);
        }
        if (s2.contains("%slot-count%")) {
            s2 = s2.replaceAll("%slot-count%", this.pl.serverManager.getServerInfo(s, "max-players"));
        }
        if (s2.contains("%motd%")) {
            s2 = s2.replaceAll("%motd%", this.pl.serverManager.getServerInfo(s, "motd"));
        }
        if (s2.contains("%whitelist%")) {
            s2 = s2.replaceAll("%whitelist%", this.pl.serverManager.getServerInfo(s, "white-list"));
        }
        if (s2.contains("%max-players%")) {
            s2 = s2.replaceAll("%max-players%", this.pl.serverManager.getServerInfo(s, "max-players"));
        }
        return s2;
    }
    
    public void copyFile(final File file, final File file2) {
        try {
            final FileInputStream fileInputStream = new FileInputStream(file);
            final FileOutputStream fileOutputStream = new FileOutputStream(file2);
            final byte[] array = new byte[1024];
            int read;
            while ((read = fileInputStream.read(array)) > 0) {
                fileOutputStream.write(array, 0, read);
            }
            fileInputStream.close();
            fileOutputStream.close();
        }
        catch (IOException ex) {
            this.log(Level.SEVERE, "Failed to copy file (" + file.getPath() + "). Please send this stack trace to the developer.");
            ex.printStackTrace();
        }
    }
    
    protected void vCheck() {
        this.pl.proxy.getScheduler().runAsync((Plugin)this.pl, (Runnable)new Runnable() {
            @Override
            public void run() {
                try {
                    final String line = new BufferedReader(new InputStreamReader(new URL("http://cakemine.net/inc/chkup.php?sk=playerservers&vrs=" + Utils.this.pl.vers).openStream())).readLine();
                    final String s = Utils.this.pl.getDescription().getVersion().split("\\-")[0];
                    if (line != null && !line.equalsIgnoreCase(s)) {
                        Utils.this.log(Level.WARNING, "PlayerServers update " + line + " available! You're on " + s);
                    }
                }
                catch (MalformedURLException ex) {}
                catch (IOException ex2) {}
            }
        });
    }
    
    public int memStringToInt(String s) {
        if (Pattern.compile("[mM]").matcher(s).find()) {
            s = s.replaceAll("[MmBb]", "");
            return Integer.valueOf(s);
        }
        if (Pattern.compile("[Gg]").matcher(s).find()) {
            s = s.replaceAll("[GgBb]", "");
            return Integer.valueOf(s) * 1024;
        }
        return Integer.valueOf(s);
    }
    
    public boolean hasPerm(final CommandSender commandSender, final String s) {
        if (!(commandSender instanceof ProxiedPlayer)) {
            return true;
        }
        final ProxiedPlayer proxiedPlayer = (ProxiedPlayer)commandSender;
        final String string = proxiedPlayer.getUniqueId().toString();
        return proxiedPlayer.hasPermission(s) || (this.pl.permMap.containsKey(string) && this.pl.permMap.get(string).get(s) != null && this.pl.permMap.get(string).get(s).equalsIgnoreCase("true"));
    }
    
    public boolean hasPerm(final String s, final String s2) {
        return this.pl.permMap.containsKey(s) && this.pl.permMap.get(s).get(s2) != null && this.pl.permMap.get(s).get(s2).equalsIgnoreCase("true");
    }
    
    public void sendTitle(final ProxiedPlayer proxiedPlayer, final String s) {
        if (s == null) {
            this.log(Level.WARNING, "Title Message missing somehow! Update your messages.yml, MOVE it (to keep a backup of your changes) and let it regenerate.");
            return;
        }
        if (s.isEmpty()) {
            return;
        }
        final String[] split = s.split("\\|\\|");
        this.debug("lines length = " + split.length);
        if (split.length < 2) {
            this.sendTitlePart(proxiedPlayer, split[0], null);
        }
        else if (split.length == 3) {
            this.sendTitlePart(proxiedPlayer, split[0], split[1]);
            this.sendActionBar(proxiedPlayer, split[2]);
        }
        else if (split.length > 3) {
            int n = 1;
            int n2 = 1;
            for (final String s2 : split) {
                if (n % 2 == 0) {
                    if (n2 != 0) {
                        this.debug("sending first title:" + split[n - 2] + "||" + split[n - 1]);
                        this.sendTitlePart(proxiedPlayer, split[n - 2], split[n - 1]);
                        n2 = 0;
                    }
                    else {
                        this.pl.proxy.getScheduler().schedule((Plugin)this.pl, (Runnable)new Runnable() {
                            @Override
                            public void run() {
                                Utils.this.debug("sending more titles:" + split[n - 2] + "||" + split[n - 1]);
                                Utils.this.sendTitlePart(proxiedPlayer, split[n - 2], split[n - 1]);
                            }
                        }, 3L, TimeUnit.SECONDS);
                    }
                }
                else if (split.length == n) {
                    this.debug("sending only title: " + split[n - 1]);
                    this.sendTitlePart(proxiedPlayer, split[n - 1], null);
                }
                ++n;
            }
        }
        else {
            this.sendTitlePart(proxiedPlayer, split[0], split[1]);
        }
    }
    
    public void sendTitlePart(final ProxiedPlayer proxiedPlayer, final String s, final String s2) {
        final Title title = this.pl.proxy.createTitle();
        if (s != null) {
            title.title((BaseComponent)new TextComponent(TextComponent.fromLegacyText(this.color(s))));
        }
        if (s2 != null) {
            title.subTitle((BaseComponent)new TextComponent(TextComponent.fromLegacyText(this.color(s2))));
        }
        title.fadeIn(10);
        title.stay(80);
        title.fadeOut(30);
        if (s != null || s2 != null) {
            title.send(proxiedPlayer);
        }
    }
    
    public void sendActionBar(final ProxiedPlayer proxiedPlayer, final String s) {
        if (s == null) {
            this.log(Level.WARNING, "Action Bar Message missing somehow! Update your messages.yml, MOVE it (to keep a backup of your changes) and let it regenerate.");
            return;
        }
        if (s.isEmpty()) {
            return;
        }
        proxiedPlayer.sendMessage(ChatMessageType.ACTION_BAR, (BaseComponent)new TextComponent(TextComponent.fromLegacyText(this.color(s))));
    }
    
    public CommandSender getSender(final String s) {
        if (!s.equalsIgnoreCase("console")) {
            return (CommandSender)this.pl.proxy.getPlayer(UUID.fromString(s));
        }
        return this.pl.proxy.getConsole();
    }
    
    public Server getCurrentServer(final String s) {
        final ProxiedPlayer player = this.pl.proxy.getPlayer(UUID.fromString(s));
        if (player == null) {
            this.debug("getCurrentServer of " + s + " failed! Player was null.");
            return null;
        }
        if (player.getServer() == null) {
            this.debug("getCurrentServer of " + s + " failed! Player was found but server was null.");
        }
        return player.getServer();
    }
}
