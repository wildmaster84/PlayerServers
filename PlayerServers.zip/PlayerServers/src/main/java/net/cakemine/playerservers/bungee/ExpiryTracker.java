package net.cakemine.playerservers.bungee;

import net.md_5.bungee.api.*;
import net.md_5.bungee.api.connection.*;
import java.text.*;
import java.util.concurrent.*;
import java.util.*;
import java.io.*;

public class ExpiryTracker
{
    PlayerServers pl;
    ProxyServer proxy;
    
    public ExpiryTracker(final PlayerServers pl) {
        this.proxy = ProxyServer.getInstance();
        this.pl = pl;
    }
    
    public void addTime(final ProxiedPlayer proxiedPlayer, final int n, final String s) {
        this.addTime(proxiedPlayer.getUniqueId().toString(), n, s);
    }
    
    public void addTime(final String s, final int n, final String s2) {
        final String date = this.getDate(s);
        final int convertDateUnit = this.convertDateUnit(s2);
        final Calendar instance = Calendar.getInstance();
        final SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm");
        if (date == null) {
            instance.add(convertDateUnit, n);
        }
        else if (this.msLeft(s) <= 0L) {
            instance.add(convertDateUnit, n);
        }
        else {
            try {
                instance.setTime(simpleDateFormat.parse(date));
            }
            catch (ParseException ex) {
                ex.printStackTrace();
            }
            instance.add(convertDateUnit, n);
        }
        this.pl.serverManager.setServerInfo(s, "expire-date", simpleDateFormat.format(instance.getTime()));
    }
    
    public void removeTime(final ProxiedPlayer proxiedPlayer, final int n, final String s) {
        this.removeTime(proxiedPlayer.getUniqueId().toString(), n, s);
    }
    
    public void removeTime(final String s, final int n, final String s2) {
        final String date = this.getDate(s);
        final Calendar instance = Calendar.getInstance();
        final int convertDateUnit = this.convertDateUnit(s2);
        final SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm");
        try {
            instance.setTime(simpleDateFormat.parse(date));
        }
        catch (ParseException ex) {
            ex.printStackTrace();
        }
        instance.add(convertDateUnit, -n);
        this.pl.serverManager.setServerInfo(s, "expire-date", simpleDateFormat.format(instance.getTime()));
    }
    
    public int daysLeft(final ProxiedPlayer proxiedPlayer) {
        return this.daysLeft(proxiedPlayer.getUniqueId().toString());
    }
    
    public int daysLeft(final String s) {
        return (int)Math.round(Math.ceil(this.msLeft(s)) / 8.64E7f);
    }
    
    public long msLeft(final String s) {
        final String date = this.getDate(s);
        final Calendar instance = Calendar.getInstance();
        final SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm");
        try {
            instance.setTime(simpleDateFormat.parse(date));
        }
        catch (ParseException ex) {
            ex.printStackTrace();
        }
        return instance.getTimeInMillis() - Calendar.getInstance().getTimeInMillis();
    }
    
    public long stringToMillis(final String s) {
        if (!s.matches("(?i)(.*)(month|mnth|mnt|mth|mo|week|wk|wek|w|day|dy|d|hour|hr|h|minute|min|mi|m|sec|second)(s)?")) {
            return -1L;
        }
        final int intValue = Integer.valueOf(s.replaceAll("(?i)([A-Z]|\\s|\\-)", ""));
        s.replaceAll("(?i)([0-9]|\\s|\\-)", "");
        if (s.matches("(?i)(.*)(month|mnth|mnt|mth|mo)(s)?")) {
            return TimeUnit.DAYS.toMillis(intValue * 30);
        }
        if (s.matches("(?i)(.*)(week|wk|wek|w)(s)?")) {
            return TimeUnit.DAYS.toMillis(intValue * 7);
        }
        if (s.matches("(?i)(.*)(day|dy|d)(s)?")) {
            return TimeUnit.DAYS.toMillis(intValue);
        }
        if (s.matches("(?i)(.*)(hour|hr|h)(s)?")) {
            return TimeUnit.HOURS.toMillis(intValue);
        }
        if (s.matches("(?i)(.*)(minute|min|mi|m)(s)?")) {
            return TimeUnit.MINUTES.toMillis(intValue);
        }
        if (s.matches("(?i)(.*)(sec|second(s)?)")) {
            return TimeUnit.SECONDS.toMillis(intValue);
        }
        return -1L;
    }
    
    public String timeLeft(final String s) {
        return this.niceTime(this.msLeft(s));
    }
    
    public String niceTime(long n) {
        final long n2 = 1000L;
        final long n3 = 60L * n2;
        final long n4 = 60L * n3;
        final long n5 = 24L * n4;
        final double n6 = 2.63E9;
        final StringBuilder sb = new StringBuilder();
        if (n > n6) {
            final int n7 = (int)Math.round(n / n6);
            sb.append(n7);
            if (n7 == 1) {
                sb.append(" month ");
            }
            else {
                sb.append(" months ");
            }
            n %= (long)n6;
        }
        if (n > n5) {
            final int n8 = (int)Math.round(Math.ceil(n / n5));
            sb.append(n8);
            if (n8 == 1) {
                sb.append(" day ");
            }
            else {
                sb.append(" days ");
            }
            n %= n5;
        }
        if (n > n4) {
            final int n9 = (int)Math.round(Math.ceil(n / n4));
            sb.append(n9);
            if (n9 == 1) {
                sb.append(" hour ");
            }
            else {
                sb.append(" hours ");
            }
            n %= n4;
        }
        if (n > n3) {
            final int n10 = (int)Math.round(Math.ceil(n / n3));
            sb.append(n10);
            if (n10 == 1) {
                sb.append(" min ");
            }
            else {
                sb.append(" mins ");
            }
            n %= n3;
        }
        if (n > n2 && sb.length() < 2) {
            sb.append((int)Math.round(Math.ceil(n / n2)));
            sb.append(" seconds ");
        }
        if (sb.length() > 1) {
            if (sb.charAt(sb.length() - 1) == ' ') {
                sb.deleteCharAt(sb.length() - 1);
            }
        }
        else {
            sb.append("0 min");
        }
        return sb.toString();
    }
    
    public String expireDate(final ProxiedPlayer proxiedPlayer) {
        return this.expireDate(proxiedPlayer.getUniqueId().toString());
    }
    
    public String expireDate(final String s) {
        final String date = this.getDate(s);
        final Calendar instance = Calendar.getInstance();
        try {
            instance.setTime(new SimpleDateFormat("yyyy-MM-dd HH:mm").parse(date));
        }
        catch (ParseException ex) {
            ex.printStackTrace();
        }
        return new SimpleDateFormat("MM/dd/yyyy").format(instance.getTime());
    }
    
    public int convertDateUnit(final String s) {
        int n = 5;
        if (s.matches("(?i)(month|mnth|mnt|mth|mo)(s)?")) {
            n = 2;
        }
        else if (s.matches("(?i)(week|wk|wek|w)(s)?")) {
            n = 3;
        }
        else if (s.matches("(?i)(day|dy|d)(s)?")) {
            n = 5;
        }
        else if (s.matches("(?i)(hour|hr|h)(s)?")) {
            n = 11;
        }
        else if (s.matches("(?i)(minute|min|mi|m)(s)?")) {
            n = 12;
        }
        this.pl.utils.debug("unit = " + s + " | unitConv = " + n);
        return n;
    }
    
    public boolean validUnit(final String s) {
        return s.matches("(?i)(month|mnth|mnt|mth|mo|week|wk|wek|w|day|dy|d|hour|hr|h|minute|min|mi|m)(s)?");
    }
    
    public String getDate(final String s) {
        if (!this.pl.serverManager.serverMap.containsKey(s) || !this.pl.serverManager.serverMap.get(s).containsKey("expire-date") || this.pl.serverManager.serverMap.get(s).get("expire-date").isEmpty()) {
            return "1989-04-20 16:20";
        }
        return this.pl.serverManager.serverMap.get(s).get("expire-date");
    }
}
