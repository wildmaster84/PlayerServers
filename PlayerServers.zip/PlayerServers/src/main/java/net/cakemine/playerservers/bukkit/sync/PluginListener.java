package net.cakemine.playerservers.bukkit.sync;

import org.bukkit.plugin.messaging.*;
import org.bukkit.entity.*;
import net.cakemine.playerservers.bukkit.*;
import org.bukkit.*;
import java.util.*;
import org.bukkit.inventory.*;
import java.io.*;

public class PluginListener implements PluginMessageListener
{
    PlayerServers pl;
    PluginSender pSend;
    
    public PluginListener(final PlayerServers pl) {
        this.pl = pl;
    }
    
    public void onPluginMessageReceived(final String s, final Player player, final byte[] array) {
        final DataInputStream dataInputStream = new DataInputStream(new ByteArrayInputStream(array));
        try {
            final String utf = dataInputStream.readUTF();
            this.pl.utils.debug("pluginmessage subchannel = " + utf);
            final String utf2 = dataInputStream.readUTF();
            final String s2 = utf;
            switch (s2) {
                case "psCustomCmd": {
                    final PluginSender sender = this.pl.sender;
                    ++sender.syncCount;
                    break;
                }
                case "test": {
                    this.pl.utils.log("TEST SUCCESS!");
                    break;
                }
                case "messages": {
                    for (final String s3 : utf2.split("––")) {
                        final String s4 = s3.split(":")[0];
                        this.pl.messages.put(s4, s3.substring(s4.length() + 1));
                    }
                    this.pl.utils.debug("Loaded messages count " + this.pl.messages.size());
                    final PluginSender sender2 = this.pl.sender;
                    ++sender2.syncCount;
                    break;
                }
                case "prefix": {
                    this.pl.prefix = ChatColor.translateAlternateColorCodes('&', utf2);
                    this.pl.utils.debug("prefix = " + this.pl.prefix);
                    final PluginSender sender3 = this.pl.sender;
                    ++sender3.syncCount;
                    break;
                }
                case "fallback": {
                    this.pl.fallbackSrv = utf2;
                    this.pl.utils.debug("fallbackSrv = " + this.pl.fallbackSrv);
                    final PluginSender sender4 = this.pl.sender;
                    ++sender4.syncCount;
                    break;
                }
                case "expiredate": {
                    this.pl.expireDate = utf2;
                    this.pl.utils.debug("expireDate = " + this.pl.expireDate);
                    final PluginSender sender5 = this.pl.sender;
                    ++sender5.syncCount;
                    break;
                }
                case "daysleft": {
                    this.pl.daysLeft = utf2;
                    this.pl.utils.debug("daysLeft = " + this.pl.daysLeft);
                    final PluginSender sender6 = this.pl.sender;
                    ++sender6.syncCount;
                    break;
                }
                case "timeleft": {
                    this.pl.timeLeft = utf2;
                    this.pl.utils.debug("timeLeft = " + this.pl.daysLeft);
                    final PluginSender sender7 = this.pl.sender;
                    ++sender7.syncCount;
                    break;
                }
                case "useExpire": {
                    this.pl.useExpire = Boolean.valueOf(utf2);
                    this.pl.utils.debug("useExpire = " + this.pl.useExpire);
                    if (this.pl.useExpire && this.pl.isSlave()) {
                        this.pl.expiryTask();
                    }
                    final PluginSender sender8 = this.pl.sender;
                    ++sender8.syncCount;
                    break;
                }
                case "expirecheck": {
                    this.pl.msLeft = Long.valueOf(utf2);
                    this.pl.utils.debug("msLeft = " + this.pl.msLeft);
                    if (this.pl.useExpire && this.pl.expireShutdown && this.pl.msLeft <= 0L) {
                        this.pl.utils.shutdown(20);
                        this.pl.utils.log("Shut down server because it expired!");
                    }
                    final PluginSender sender9 = this.pl.sender;
                    ++sender9.syncCount;
                    break;
                }
                case "blockedcmds": {
                    PlayerListener.blockedCmds.clear();
                    Collections.addAll(PlayerListener.blockedCmds, utf2.split("(%%%)"));
                    this.pl.listener.updateCmds();
                    this.pl.utils.debug("blockedCmds = " + PlayerListener.blockedCmds);
                    this.pl.cmdsLoaded = true;
                    final PluginSender sender10 = this.pl.sender;
                    ++sender10.syncCount;
                    break;
                }
                case "alwaysops": {
                    PlayerListener.alwaysOps.clear();
                    for (final String s5 : utf2.split("(%%%)")) {
                        PlayerListener.alwaysOps.add(s5);
                        final Player player2;
                        if (!s5.matches("[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}") && (player2 = Bukkit.getPlayer(s5)) != null) {
                            player2.setWhitelisted(true);
                            player2.setOp(true);
                            this.pl.utils.debug("OPing " + player2.getName() + " because their name is on the always-op list.");
                        }
                        else {
                            final Player player3;
                            if (s5.matches("[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}") && (player3 = Bukkit.getPlayer(UUID.fromString(s5))) != null) {
                                player3.setWhitelisted(true);
                                player3.setOp(true);
                                this.pl.utils.debug("OPing " + player3.getName() + " because their UUID is on the always-op list.");
                            }
                        }
                    }
                    final PluginSender sender11 = this.pl.sender;
                    ++sender11.syncCount;
                    break;
                }
                case "debug": {
                    this.pl.debug = utf2.equals("1");
                    this.pl.utils.debug("DEBUG is TRUE if you can read this");
                    final PluginSender sender12 = this.pl.sender;
                    ++sender12.syncCount;
                    break;
                }
                case "templates": {
                    final String[] split3 = utf2.split("%%%");
                    this.pl.templates.clear();
                    final String[] array2 = split3;
                    for (int length3 = array2.length, k = 0; k < length3; ++k) {
                        final String[] split4 = array2[k].split("&&&");
                        String s6 = null;
                        String s7 = null;
                        String s8 = null;
                        String s9 = null;
                        final String[] array3 = split4;
                        for (int length4 = array3.length, l = 0; l < length4; ++l) {
                            final String[] split5 = array3[l].split("::");
                            final String s10 = split5[0];
                            final String s11 = split5[1];
                            final String s12 = s10;
                            switch (s12) {
                                case "name": {
                                    s6 = s11;
                                    break;
                                }
                                case "icon": {
                                    s7 = s11;
                                    break;
                                }
                                case "desc": {
                                    s8 = s11;
                                    break;
                                }
                                case "OP": {
                                    s9 = s11;
                                    break;
                                }
                            }
                        }
                        this.pl.templates.put(s6, new HashMap<String, String>());
                        this.pl.templates.get(s6).put("icon", s7);
                        this.pl.templates.get(s6).put("desc", s8);
                        this.pl.templates.get(s6).put("OP", s9);
                    }
                    this.pl.utils.debug("Loaded Template Count = " + this.pl.templates.size());
                    final PluginSender sender13 = this.pl.sender;
                    ++sender13.syncCount;
                    break;
                }
                case "controlGUI": {
                    this.pl.utils.debug("input = " + utf2);
                    final String[] split6 = utf2.split("———");
                    final String s13 = split6[0];
                    final HashMap<String, String> hashMap = new HashMap<String, String>();
                    if (split6.length > 1) {
                        final String[] split7 = split6[1].split("%%%");
                        for (int length5 = split7.length, n3 = 0; n3 < length5; ++n3) {
                            final String[] split8 = split7[n3].split("###");
                            hashMap.put(split8[0], split8[1]);
                        }
                    }
                    this.pl.gui.getGUI("control").open(this.pl.getServer().getPlayer(UUID.fromString(s13)), null, 0, hashMap);
                    break;
                }
                case "worldselect": {
                    this.pl.gui.getGUI("templates").open(this.pl.getServer().getPlayer(UUID.fromString(utf2)), null, 0);
                    break;
                }
                case "serverselect": {
                    this.pl.utils.debug("input = " + utf2);
                    final String[] split9 = utf2.split("———");
                    final String s14 = split9[0];
                    final HashMap<String, HashMap<String, String>> hashMap2 = new HashMap<String, HashMap<String, String>>();
                    if (split9.length > 1) {
                        for (final String s15 : split9[1].split("@@@")) {
                            final String s16 = s15.split(":::")[0];
                            final HashMap<String, String> hashMap3 = new HashMap<String, String>();
                            for (final String s17 : s15.split(":::")[1].split("%%%")) {
                                hashMap3.put(s17.split("###")[0], s17.split("###")[1]);
                            }
                            hashMap2.put(s16, hashMap3);
                        }
                    }
                    this.pl.gui.getGUI("servers").open(this.pl.getServer().getPlayer(UUID.fromString(s14)), null, 0, hashMap2);
                    break;
                }
                case "reSync": {
                    this.pl.listener.syncDone = false;
                    this.pl.sender.syncCount = 0;
                    this.pl.sender.syncTotal = 0;
                    break;
                }
                case "finishSync": {
                    this.pl.sender.syncTotal = Integer.valueOf(utf2);
                    this.pl.sender.confirmSync();
                    break;
                }
                case "version": {
                    this.pl.sender.versionMatcher(utf2);
                    final PluginSender sender14 = this.pl.sender;
                    ++sender14.syncCount;
                    break;
                }
                case "guis": {
                    this.pl.gui.deserializeGUIs(utf2);
                    final PluginSender sender15 = this.pl.sender;
                    ++sender15.syncCount;
                    break;
                }
            }
            dataInputStream.close();
        }
        catch (IOException ex) {
            ex.printStackTrace();
        }
    }
}
