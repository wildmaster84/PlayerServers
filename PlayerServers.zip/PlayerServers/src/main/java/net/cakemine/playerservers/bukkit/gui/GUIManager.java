package net.cakemine.playerservers.bukkit.gui;

import net.cakemine.playerservers.bukkit.*;
import org.bukkit.entity.*;
import org.bukkit.event.inventory.*;
import org.bukkit.enchantments.*;
import java.lang.reflect.*;
import org.bukkit.*;
import java.util.logging.*;
import org.bukkit.inventory.*;
import java.util.*;
import org.bukkit.inventory.meta.*;

public class GUIManager
{
    PlayerServers pl;
    public SelectedEnchant SELECTED;
    public HashMap<String, CustomGUI> customGUIs;
    
    public GUIManager(final PlayerServers pl) {
        this.SELECTED = new SelectedEnchant(419);
        this.customGUIs = new HashMap<String, CustomGUI>();
        this.pl = pl;
    }
    
    public void openAnvil(final Player player, final String s) {
        player.openInventory(Bukkit.createInventory((InventoryHolder)null, InventoryType.ANVIL, this.pl.utils.color(s)));
    }
    
    public CustomGUI getGUI(final String s) {
        if (this.customGUIs.containsKey(s)) {
            return this.customGUIs.get(s);
        }
        return this.customGUIs.entrySet().iterator().next().getValue();
    }
    
    public void initSelector() {
        try {
            final Field declaredField = Enchantment.class.getDeclaredField("acceptingNew");
            declaredField.setAccessible(true);
            declaredField.set(null, true);
            Enchantment.registerEnchantment((Enchantment)this.SELECTED);
        }
        catch (Exception ex) {
            this.pl.utils.log("Failed to register selector (glow) enchant.");
        }
    }
    
    public void deserializeGUIs(final String s) {
        final String s2 = "¶¶¶";
        final String s3 = "æææ";
        final String s4 = "%#%";
        final String s5 = "#%#";
        final String s6 = "#@#";
        final String s7 = "@@@";
        for (final String s8 : s.split(s2)) {
            final String s9 = s8.split(s4)[0];
            final String title = s8.split(s4)[1];
            if (s9.matches("\\w{1,}(-\\w{1,})?-title")) {
                this.getGUI(s9.replaceAll("-title", "")).setTitle(title);
            }
            if (s9.equalsIgnoreCase("go-back-item")) {
                String s10 = title;
                int n = 0;
                if (title.contains(":")) {
                    s10 = title.split(":")[0];
                    n = (title.split(":")[1].matches("\\d+") ? ((short)Short.valueOf(title.split(":")[1])) : 0);
                }
                final Iterator<Map.Entry<String, CustomGUI>> iterator = this.customGUIs.entrySet().iterator();
                while (iterator.hasNext()) {
                    iterator.next().getValue().setBackButton(this.item(1, Material.matchMaterial(s10), n, "&c&lGo Back.", null));
                }
            }
            else if (s9.equalsIgnoreCase("fill-item")) {
                String s11 = title;
                short n2 = 0;
                if (title.contains(":")) {
                    s11 = title.split(":")[0];
                    n2 = (short)(title.split(":")[1].matches("\\d+") ? ((short)Short.valueOf(title.split(":")[1])) : 0);
                }
                final Iterator<Map.Entry<String, CustomGUI>> iterator2 = this.customGUIs.entrySet().iterator();
                while (iterator2.hasNext()) {
                    iterator2.next().getValue().setFillItem(Material.matchMaterial(s11), n2);
                }
            }
            else if (s9.matches("\\w{1,}(-\\w{1,})?-icons")) {
                final String replaceAll = s9.replaceAll("-icons", "");
                for (final String s12 : title.split(s3)) {
                    final String s13 = s12.split(s5)[0];
                    final String s14 = s12.split(s5)[1];
                    Material material = Material.BEDROCK;
                    int n3 = 0;
                    String s15 = "none/error";
                    String s16 = "none/error";
                    for (final String s17 : s14.split(s7)) {
                        final String s18 = s17.split(s6)[0];
                        final String s19 = s17.split(s6)[1];
                        final String s20 = s18;
                        switch (s20) {
                            case "item-id": {
                                final String upperCase = s19.toUpperCase();
                                if (s18.equals("player")) {
                                    material = Material.SKULL_ITEM;
                                    n3 = 3;
                                }
                                else if (upperCase.matches("(?i)^(.*):\\d+$")) {
                                    material = Material.matchMaterial(upperCase.split(":")[0]);
                                    n3 = (upperCase.split(":")[1].matches("\\d+") ? ((short)Short.valueOf(upperCase.split(":")[1])) : 0);
                                }
                                else {
                                    material = Material.matchMaterial(upperCase);
                                }
                                if (material == null) {
                                    this.pl.utils.log(Level.WARNING, "Material \"" + upperCase + "\" not found! Defaulting to bedrock for \"" + s13 + "\" GUI item.");
                                    material = Material.BEDROCK;
                                    break;
                                }
                                break;
                            }
                            case "item-name": {
                                s15 = s19;
                                break;
                            }
                            case "item-lore": {
                                s16 = s19;
                                break;
                            }
                        }
                    }
                    this.getGUI(replaceAll).addItem(s13, this.item(1, material, n3, s15, s16));
                }
            }
        }
    }
    
    public void registerGUIs() {
        this.initSelector();
        this.putGUI("settings", new SettingsGUI(this.pl));
        this.putGUI("gamemode", new GamemodeGUI(this.pl));
        this.putGUI("difficulty", new DifficultyGUI(this.pl));
        this.putGUI("whitelist", new WhitelistGUI(this.pl));
        this.putGUI("player-manager", new PlayerManageGUI(this.pl));
        this.putGUI("player", new PlayerGUI(this.pl));
        this.putGUI("mob-settings", new MobGUI(this.pl));
        this.putGUI("world-settings", new WorldGUI(this.pl));
        this.putGUI("templates", new TemplatesGUI(this.pl));
        this.putGUI("servers", new ServersGUI(this.pl));
        this.putGUI("control", new ControlGUI(this.pl));
    }
    
    public void putGUI(final String s, final CustomGUI customGUI) {
        this.customGUIs.put(s, customGUI);
    }
    
    public ItemStack item(final int n, final Material material, final int n2, final String s, final String s2) {
        final ItemStack itemStack = new ItemStack(material, n);
        final ItemMeta itemMeta = itemStack.getItemMeta();
        itemStack.setDurability((short)n2);
        if (s != null) {
            itemMeta.setDisplayName(this.pl.utils.color(s));
        }
        if (s2 != null) {
            itemMeta.setLore((List)Arrays.asList(this.pl.utils.color(s2).split("(\\|\\||\n|\\n|\\{n\\})")));
        }
        itemStack.setItemMeta(itemMeta);
        return itemStack;
    }
}
