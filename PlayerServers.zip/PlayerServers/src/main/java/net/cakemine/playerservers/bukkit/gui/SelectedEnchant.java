package net.cakemine.playerservers.bukkit.gui;

import org.bukkit.enchantments.*;
import org.bukkit.inventory.*;

public class SelectedEnchant extends Enchantment
{
    public SelectedEnchant(final int n) {
        super(n);
    }
    
    public String getName() {
        return "";
    }
    
    public int getMaxLevel() {
        return 1;
    }
    
    public int getStartLevel() {
        return 0;
    }
    
    public EnchantmentTarget getItemTarget() {
        return null;
    }
    
    public boolean conflictsWith(final Enchantment enchantment) {
        return false;
    }
    
    public boolean canEnchantItem(final ItemStack itemStack) {
        return true;
    }
}
