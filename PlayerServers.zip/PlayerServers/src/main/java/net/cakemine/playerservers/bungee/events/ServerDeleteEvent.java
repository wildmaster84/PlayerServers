package net.cakemine.playerservers.bungee.events;

import net.md_5.bungee.api.plugin.*;
import net.cakemine.playerservers.bungee.*;
import java.util.*;
import java.io.*;

public class ServerDeleteEvent extends Event implements Cancellable
{
    PlayerServers pl;
    private boolean cancelled;
    private final UUID uuid;
    private final String serverName;
    private final int port;
    private final int memx;
    private final int mems;
    
    public ServerDeleteEvent(final PlayerServers pl, final UUID uuid, final String serverName, final int port, final int memx, final int mems) {
        this.cancelled = false;
        this.pl = pl;
        this.uuid = uuid;
        this.serverName = serverName;
        this.port = port;
        this.memx = memx;
        this.mems = mems;
    }
    
    public UUID getOwnerId() {
        return this.uuid;
    }
    
    public String getOwnerName() {
        return this.pl.utils.getName(this.uuid.toString());
    }
    
    public String getServerName() {
        return this.serverName;
    }
    
    public int getServerPort() {
        return this.port;
    }
    
    public int getXmx() {
        return this.memx;
    }
    
    public int getXms() {
        return this.mems;
    }
    
    public File getServerFolder() {
        return new File(this.pl.serversFolder + File.separator + this.uuid);
    }
    
    public boolean isCancelled() {
        return this.cancelled;
    }
    
    public void setCancelled(final boolean cancelled) {
        this.cancelled = cancelled;
    }
}
