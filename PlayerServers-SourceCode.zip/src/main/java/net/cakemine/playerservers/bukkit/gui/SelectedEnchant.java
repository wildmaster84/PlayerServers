package net.cakemine.playerservers.bukkit.gui;

import org.bukkit.NamespacedKey;
import org.bukkit.enchantments.*;
import org.bukkit.inventory.*;

public class SelectedEnchant extends Enchantment
{
    public SelectedEnchant(NamespacedKey n) {
        super(n);
    }
    
    public String getName() {
        return "";
    }
    
    public int getMaxLevel() {
        return 1;
    }
    
    public int getStartLevel() {
        return 0;
    }
    
    public EnchantmentTarget getItemTarget() {
        return null;
    }
    
    public boolean conflictsWith(Enchantment enchantment) {
        return false;
    }
    
    public boolean canEnchantItem(ItemStack itemStack) {
        return true;
    }

	@Override
	public boolean isTreasure() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean isCursed() {
		// TODO Auto-generated method stub
		return false;
	}
}
