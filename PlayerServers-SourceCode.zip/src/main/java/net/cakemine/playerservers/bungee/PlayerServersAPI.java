package net.cakemine.playerservers.bungee;

import net.md_5.bungee.api.connection.*;
import net.cakemine.playerservers.bungee.events.*;
import net.md_5.bungee.api.plugin.*;
import net.md_5.bungee.api.*;
import java.io.*;
import net.md_5.bungee.config.*;
import java.util.*;

public class PlayerServersAPI
{
    PlayerServers pl;
    
    PlayerServersAPI(PlayerServers pl) {
        this.pl = pl;
    }
    
    public boolean getDebugMode() {
        return this.pl.debug;
    }
    
    public void debugLog(String s) {
        this.pl.utils.debug(s);
    }
    
    public String getPluginPrefix() {
        return this.pl.prefix;
    }
    
    public void setPluginPrefix(String prefix) {
        this.pl.prefix = prefix;
    }
    
    public void reSync(Server server) {
        this.pl.sender.reSync(server);
    }
    
    public void reSyncAll() {
        this.pl.sender.reSyncAll();
    }
    
    public LinkedHashMap<String, HashMap<String, String>> getServerMap() {
        return this.pl.serverManager.serverMap;
    }
    
    public String getServerMapSetting(String s, String s2) {
        return this.pl.serverManager.serverMap.get(s).get(s2);
    }
    
    public void setServerMapSetting(String s, String s2, String s3) {
        this.pl.serverManager.setServerInfo(s, s2, s3);
    }
    
    public void clearServerMapSetting(String s, String s2) {
        this.pl.serverManager.serverMap.get(s).remove(s2);
        this.pl.proxy.getPluginManager().callEvent((Event)new ServerModifyEvent(this.pl, s));
    }
    
    public void saveServerMap() {
        this.pl.serverManager.saveServerMap();
    }
    
    public List<String> getOnlinePlayerServers() {
        return this.pl.serverManager.playerServers;
    }
    
    public boolean getServerOnline(String s) {
        String serverUUID = this.pl.utils.getServerUUID(s);
        return !this.pl.utils.isPortOpen(this.pl.utils.getSrvIp(serverUUID), this.pl.utils.getSrvPort(serverUUID));
    }
    
    public boolean serverFilesExist(String s) {
        return this.pl.serverManager.serverFilesExist(this.pl.serverManager.getOwnerId(s));
    }
    
    public boolean serverFilesExistUUID(String s) {
        return this.pl.serverManager.serverFilesExist(s);
    }
    
    public UUID getServerOwnerId(String s) {
        return UUID.fromString(this.pl.utils.getServerUUID(s));
    }
    
    public String getServerOwnerName(String s) {
        return this.pl.utils.getName(this.pl.serverManager.getOwnerId(s));
    }
    
    public String getServerTemplateName(String s) {
        return this.pl.serverManager.getServerTemplateName(s);
    }
    
    public int getServerXmx(String s) {
        if (this.pl.serverManager.getOwnerId(s) == null) {
            return 0;
        }
        return this.pl.utils.memStringToInt(this.pl.serverManager.serverMap.get(this.pl.serverManager.getOwnerId(s)).get("memory").split("\\/")[0]);
    }
    
    public int getServerXms(String s) {
        if (this.pl.serverManager.getOwnerId(s) == null) {
            return 0;
        }
        return this.pl.utils.memStringToInt(this.pl.serverManager.serverMap.get(this.pl.serverManager.getOwnerId(s)).get("memory").split("\\/")[1]);
    }
    
    public String getPlayerServerName(UUID uuid) {
        return this.pl.utils.getSrvName(uuid.toString());
    }
    
    public void setPlayerServerName(UUID uuid, String s) {
        this.pl.serverManager.setServerInfo(uuid.toString(), "server-name", s);
    }
    
    public int getPlayerServerPort(UUID uuid) {
        return this.pl.utils.getSrvPort(uuid.toString());
    }
    
    public String getPropertiesSetting(UUID uuid, String s) {
        return this.pl.settingsManager.getSetting(uuid.toString(), s);
    }
    
    public void setPropertiesSetting(UUID uuid, String s, String s2) {
        this.pl.settingsManager.changeSetting(uuid.toString(), s, s2);
    }
    
    public void startServerName(String s) {
        this.pl.serverManager.startupSrv(this.pl.utils.getServerUUID(s), null);
    }
    
    public void startServerUUID(UUID uuid) {
        this.pl.serverManager.startupSrv(uuid.toString(), null);
    }
    
    public void startServerPlayer(String s) {
        this.pl.serverManager.startupSrv(this.pl.utils.getUUID(s), null);
    }
    
    public void stopServerName(String s) {
        this.pl.serverManager.stopSrv(this.pl.utils.getServerUUID(s));
    }
    
    public void stopServerUUID(UUID uuid) {
        this.pl.serverManager.stopSrv(uuid.toString());
    }
    
    public void stopServerPlayer(String s) {
        this.pl.serverManager.stopSrv(this.pl.utils.getUUID(s));
    }
    
    public void stopAllServers() {
        this.pl.serverManager.stopAll(null);
    }
    
    public void addBungeeServer(String s, String s2, Integer n, String s3, int n2) {
        this.pl.serverManager.addBungee(s, s2, n, s3, n2);
    }
    
    public void removeBungeeServer(String s) {
        this.pl.serverManager.removeBungee(s);
    }
    
    public void createServer(UUID uuid, String s) {
        this.pl.serverManager.createServer(null, this.pl.utils.getName(uuid.toString()), uuid.toString(), this.pl.templateManager.getTemplateFile(s));
    }
    
    public void deleteServer(UUID uuid) {
        this.pl.serverManager.deleteServer(null, uuid.toString());
    }
    
    public List<String> getAvailableTemplateNames() {
        ArrayList<String> list = new ArrayList<String>();
        Iterator<File> iterator = this.pl.templateManager.templates.keySet().iterator();
        while (iterator.hasNext()) {
            list.add(this.pl.templateManager.getTemplateSetting(iterator.next(), "template-name"));
        }
        return list;
    }
    
    public String getTemplateDescription(String s) {
        if (this.pl.templateManager.getTemplateFile(s) == null) {
            return null;
        }
        return this.pl.templateManager.getTemplateSetting(this.pl.templateManager.getTemplateFile(s), "template-name");
    }
    
    public List<String> getTemplateDescriptionList(String s) {
        if (this.pl.templateManager.getTemplateFile(s) == null) {
            return null;
        }
        return Arrays.asList(this.pl.templateManager.getTemplateSetting(this.pl.templateManager.getTemplateFile(s), "template-name").split("||"));
    }
    
    public boolean isTemplateCreatorOp(String s) {
        return this.pl.templateManager.getTemplateFile(s) != null && this.pl.templateManager.getTemplateSetting(this.pl.templateManager.getTemplateFile(s), "creator-gets-op").equalsIgnoreCase("true");
    }
    
    public boolean isTemplateExpireShutdown(String s) {
        return this.pl.templateManager.getTemplateFile(s) != null && this.pl.templateManager.getTemplateSetting(this.pl.templateManager.getTemplateFile(s), "shutdown-on-expire").equalsIgnoreCase("true");
    }
    
    public String getTemplateExpiryHuman(String s) {
        if (this.pl.templateManager.getTemplateFile(s) == null) {
            return null;
        }
        return this.pl.templateManager.getTemplateSetting(this.pl.templateManager.getTemplateFile(s), "default-expiry-time");
    }
    
    public boolean setTemplateName(String s, String s2) {
        if (this.pl.templateManager.getTemplateFile(s) == null) {
            return false;
        }
        this.pl.templateManager.templates.get(this.pl.templateManager.getTemplateFile(s)).set("template-name", (Object)s2);
        return true;
    }
    
    public boolean setTemplateDescrption(String s, String s2) {
        if (this.pl.templateManager.getTemplateFile(s) == null) {
            return false;
        }
        this.pl.templateManager.templates.get(this.pl.templateManager.getTemplateFile(s)).set("description", (Object)s2);
        return true;
    }
    
    public boolean setTemplateMaterial(String s, String s2) {
        if (this.pl.templateManager.getTemplateFile(s) == null) {
            return false;
        }
        this.pl.templateManager.templates.get(this.pl.templateManager.getTemplateFile(s)).set("icon-material", (Object)s2);
        return true;
    }
    
    public boolean setTemplateCreatorOP(String s, boolean b) {
        if (this.pl.templateManager.getTemplateFile(s) == null) {
            return false;
        }
        this.pl.templateManager.templates.get(this.pl.templateManager.getTemplateFile(s)).set("creator-gets-op", (Object)b);
        return true;
    }
    
    public boolean setTemplateExpireShutdown(String s, boolean b) {
        if (this.pl.templateManager.getTemplateFile(s) == null) {
            return false;
        }
        this.pl.templateManager.templates.get(this.pl.templateManager.getTemplateFile(s)).set("shutdown-on-expire", (Object)b);
        return true;
    }
    
    public boolean setTemplateExpiryTime(String s, String s2) {
        if (this.pl.templateManager.getTemplateFile(s) == null) {
            return false;
        }
        this.pl.templateManager.templates.get(this.pl.templateManager.getTemplateFile(s)).set("default-expire-time", (Object)s2);
        return true;
    }
    
    public void addTime(UUID uuid, int n, String s) {
        this.pl.expiryTracker.addTime(uuid.toString(), n, s);
    }
    
    public void removeTime(UUID uuid, int n, String s) {
        this.pl.expiryTracker.removeTime(uuid.toString(), n, s);
    }
    
    public long getMillisLeft(UUID uuid) {
        return this.pl.expiryTracker.msLeft(uuid.toString());
    }
    
    public String getTimeLeft(UUID uuid) {
        return this.pl.expiryTracker.timeLeft(uuid.toString());
    }
    
    public String getExpireDate(UUID uuid) {
        return this.pl.expiryTracker.getDate(uuid.toString());
    }
    
    public String getPlayerName(UUID uuid) {
        return this.pl.utils.getName(uuid.toString());
    }
    
    public UUID getPlayerUUID(String s) {
        if (this.pl.utils.getUUID(s) == null) {
            return null;
        }
        return UUID.fromString(this.pl.utils.getUUID(s));
    }
    
    public void putPlayerMapEntry(String s, UUID uuid) {
        this.pl.putPlayer(s, uuid.toString());
    }
    
    public boolean removePlayerMapEntry(String s) {
        if (this.pl.playerMap.containsKey(s)) {
            this.pl.playerMap.remove(s);
            return true;
        }
        return false;
    }
    
    public boolean removedPlayerMapEntryUUID(UUID uuid) {
        boolean b = false;
        if (this.pl.playerMap.containsValue(uuid.toString())) {
            Iterator<Map.Entry<String, String>> iterator = this.pl.playerMap.entrySet().iterator();
            while (iterator.hasNext()) {
                if (iterator.next().getValue().equals(uuid.toString())) {
                    iterator.remove();
                    b = true;
                }
            }
        }
        return b;
    }
    
    public File[] listFiles(File file) {
        if (file.isDirectory()) {
            return file.listFiles();
        }
        return null;
    }
    
    public void copyFileSoft(File file, File file2) {
        this.pl.serverManager.doCopy(file, file2);
    }
    
    public void copyFileHard(File file, File file2) {
        this.pl.utils.copyFile(file, file2);
    }
    
    public void deleteFile(File file) {
        this.pl.serverManager.doDelete(file);
    }
}
